package com.example.data.model

import java.util.Locale

data class WeatherData(
    val temperature: Double = 0.0,
    val feelsLike: Double = 0.0,
    val humidity: Int = 0,
    val windSpeed: Double = 0.0,
    val condition: String = "Clear",
    val weatherCode: Int = 0,
    val isAvailable: Boolean = true,
    val errorMessage: String? = null,
    val timestamp: Long = System.currentTimeMillis()
) {
    fun formattedTemp(): String = String.format(Locale.US, "%.1f°C", temperature)

    fun formattedFeelsLike(): String = String.format(Locale.US, "%.1f°C", feelsLike)

    fun formattedWind(): String = String.format(Locale.US, "%.1f km/h", windSpeed)

    companion object {
        fun unavailable(message: String = "Weather data unavailable"): WeatherData {
            return WeatherData(
                isAvailable = false,
                errorMessage = message,
                condition = "Unavailable"
            )
        }

        fun decodeWmoCode(code: Int): String {
            return when (code) {
                0 -> "Clear sky"
                1, 2, 3 -> "Mainly clear, partly cloudy"
                45, 48 -> "Foggy"
                51, 53, 55 -> "Drizzle"
                61, 63, 65 -> "Rain showers"
                71, 73, 75 -> "Snow fall"
                80, 81, 82 -> "Rain showers"
                95, 96, 99 -> "Thunderstorm"
                else -> "Cloudy"
            }
        }
    }
}
