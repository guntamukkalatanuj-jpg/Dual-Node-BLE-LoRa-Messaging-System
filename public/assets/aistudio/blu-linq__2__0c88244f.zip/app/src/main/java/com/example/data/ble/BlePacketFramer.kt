package com.example.data.ble

import java.nio.ByteBuffer
import java.nio.ByteOrder

object BlePacketFramer {
    const val MAGIC_BYTE_0: Byte = 0xB1.toByte()
    const val MAGIC_BYTE_1: Byte = 0x01.toByte()
    const val HEADER_SIZE: Int = 9
    const val MAX_PAYLOAD_CHUNK: Int = 11
    const val MAX_FRAME_SIZE: Int = HEADER_SIZE + MAX_PAYLOAD_CHUNK // 20 bytes

    data class BleFrame(
        val messageId: Int,
        val partIndex: Int, // 1-indexed (1..totalParts)
        val totalParts: Int,
        val payload: ByteArray
    ) {
        val totalFrameLength: Int
            get() = HEADER_SIZE + payload.size

        fun toByteArray(): ByteArray {
            val buffer = ByteBuffer.allocate(HEADER_SIZE + payload.size)
            buffer.order(ByteOrder.BIG_ENDIAN)
            buffer.put(MAGIC_BYTE_0)
            buffer.put(MAGIC_BYTE_1)
            buffer.putShort((messageId and 0xFFFF).toShort())
            buffer.putShort((partIndex and 0xFFFF).toShort())
            buffer.putShort((totalParts and 0xFFFF).toShort())
            buffer.put((payload.size and 0xFF).toByte())
            buffer.put(payload)
            return buffer.array()
        }

        fun hexHeader(): String {
            return String.format(
                "%02X %02X %04X %04X %04X %02X",
                MAGIC_BYTE_0,
                MAGIC_BYTE_1,
                messageId and 0xFFFF,
                partIndex and 0xFFFF,
                totalParts and 0xFFFF,
                payload.size and 0xFF
            )
        }
    }

    /**
     * Splits UTF-8 serialized JSON into 20-byte BLE binary frames.
     */
    fun createFrames(messageId: Int, serializedJson: String): List<BleFrame> {
        val dataBytes = serializedJson.toByteArray(Charsets.UTF_8)
        val totalParts = ((dataBytes.size + MAX_PAYLOAD_CHUNK - 1) / MAX_PAYLOAD_CHUNK).coerceAtLeast(1)
        val frames = mutableListOf<BleFrame>()

        for (part in 1..totalParts) {
            val start = (part - 1) * MAX_PAYLOAD_CHUNK
            val end = (start + MAX_PAYLOAD_CHUNK).coerceAtMost(dataBytes.size)
            val chunk = if (start < dataBytes.size) {
                dataBytes.copyOfRange(start, end)
            } else {
                ByteArray(0)
            }
            frames.add(
                BleFrame(
                    messageId = messageId,
                    partIndex = part,
                    totalParts = totalParts,
                    payload = chunk
                )
            )
        }
        return frames
    }

    /**
     * Inspects incoming notification from ESP32 to check if it's an ACK
     * (e.g. "ACK|1024|1|15" or "ACK:1024:1").
     */
    fun checkIsAck(text: String, expectedMessageId: Int, expectedPart: Int): Boolean {
        val trimmed = text.trim()
        if (trimmed == "ACK") return true
        if (trimmed.startsWith("ACK|") || trimmed.startsWith("ACK:")) {
            val delimiter = if (trimmed.contains("|")) "\\|" else ":"
            val parts = trimmed.split(delimiter.toRegex())
            if (parts.size >= 3) {
                val msgId = parts[1].toIntOrNull()
                val partNum = parts[2].toIntOrNull()
                return msgId == expectedMessageId && partNum == expectedPart
            }
            return true
        }
        return false
    }
}
