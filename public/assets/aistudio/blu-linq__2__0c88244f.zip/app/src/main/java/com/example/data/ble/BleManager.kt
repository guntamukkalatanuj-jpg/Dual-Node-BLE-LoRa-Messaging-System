package com.example.data.ble

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanFilter
import android.bluetooth.le.ScanResult
import android.bluetooth.le.ScanSettings
import android.content.Context
import android.os.ParcelUuid
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import org.json.JSONObject
import java.util.concurrent.atomic.AtomicInteger

class BleManager(
    private val context: Context,
    private val scope: CoroutineScope
) {
    private val bluetoothManager = context.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager
    val bluetoothAdapter: BluetoothAdapter? = bluetoothManager?.adapter

    // 16-bit Message ID generator (starts at 1001)
    private val messageIdCounter = AtomicInteger(1001)

    // Debug logs flow (maintains last 200 log messages)
    private val _debugLogs = MutableStateFlow<List<DebugLogEntry>>(emptyList())
    val debugLogs: StateFlow<List<DebugLogEntry>> = _debugLogs.asStateFlow()

    fun addDebugLog(tag: String, message: String, isError: Boolean = false, isSuccess: Boolean = false) {
        val entry = DebugLogEntry(
            tag = tag,
            message = message,
            isError = isError,
            isSuccess = isSuccess
        )
        val current = _debugLogs.value.toMutableList()
        if (current.size >= 200) {
            current.removeAt(0)
        }
        current.add(entry)
        _debugLogs.value = current
    }

    // Two independent source node connections
    val nodeA = BleNodeConnection(
        context = context,
        nodeId = SourceNodeId.NODE_A,
        expectedName = BleConstants.NODE_A_NAME,
        scope = scope,
        onLog = ::addDebugLog
    )

    val nodeB = BleNodeConnection(
        context = context,
        nodeId = SourceNodeId.NODE_B,
        expectedName = BleConstants.NODE_B_NAME,
        scope = scope,
        onLog = ::addDebugLog
    )

    // Output node / Final Terminal connection (ESP32-D)
    val outputNode = BleNodeConnection(
        context = context,
        nodeId = SourceNodeId.OUTPUT_NODE,
        expectedName = BleConstants.OUTPUT_NODE_NAME,
        scope = scope,
        onLog = ::addDebugLog
    )

    // Scanner state
    private val _isScanning = MutableStateFlow(false)
    val isScanning: StateFlow<Boolean> = _isScanning.asStateFlow()

    private val _scanTarget = MutableStateFlow<SourceNodeId?>(null)
    val scanTarget: StateFlow<SourceNodeId?> = _scanTarget.asStateFlow()

    private val _discoveredDevices = MutableStateFlow<List<DiscoveredBleDevice>>(emptyList())
    val discoveredDevices: StateFlow<List<DiscoveredBleDevice>> = _discoveredDevices.asStateFlow()

    // Status / Alert message for snackbars
    private val _statusMessage = MutableStateFlow("Disconnected")
    val statusMessage: StateFlow<String> = _statusMessage.asStateFlow()

    // Combined incoming data stream from Node A, Node B, and Output Node
    private val _incomingDataFlow = MutableSharedFlow<String>(extraBufferCapacity = 64)
    val incomingDataFlow: SharedFlow<String> = _incomingDataFlow.asSharedFlow()

    val isBluetoothSupported: Boolean
        get() = bluetoothAdapter != null

    val isBluetoothEnabled: Boolean
        get() = bluetoothAdapter?.isEnabled == true

    // Combined Diagnostics
    val diagnostics: StateFlow<BleDiagnostics> = combine(
        nodeA.status,
        nodeB.status,
        outputNode.status,
        _isScanning
    ) { statusA, statusB, statusOut, scanning ->
        BleDiagnostics(
            isBluetoothOn = isBluetoothEnabled,
            scannerState = if (scanning) "BUSY" else "READY",
            nodeAStatus = statusA,
            nodeBStatus = statusB,
            outputNodeStatus = statusOut
        )
    }.stateIn(
        scope = scope,
        started = SharingStarted.Eagerly,
        initialValue = BleDiagnostics()
    )

    init {
        // Collect incoming notifications from Node A
        scope.launch {
            nodeA.incomingNotifications.collect { text ->
                _incomingDataFlow.emit(text)
            }
        }
        // Collect incoming notifications from Node B
        scope.launch {
            nodeB.incomingNotifications.collect { text ->
                _incomingDataFlow.emit(text)
            }
        }
        // Collect incoming notifications from Output Node (ESP32-D Final Terminal)
        scope.launch {
            outputNode.incomingNotifications.collect { text ->
                _incomingDataFlow.emit(text)
            }
        }

        addDebugLog("[SYSTEM]", "Blu-LinQ BLE Subsystem Initialized. Dual Sources & Output Node ready.")
    }

    private val scanCallback = object : ScanCallback() {
        @SuppressLint("MissingPermission")
        override fun onScanResult(callbackType: Int, result: ScanResult) {
            val device = result.device
            val scanRecord = result.scanRecord
            val address = device.address ?: return
            val rssi = result.rssi

            // Robust name discovery: inspect device.name and scan response deviceName
            val advertisedName = scanRecord?.deviceName
            val devName = try {
                device.name
            } catch (_: SecurityException) {
                null
            }
            val bestName = advertisedName ?: devName ?: "Unknown Device"

            // Check if NUS UUID is in advertised service list
            val serviceUuids = scanRecord?.serviceUuids?.map { it.uuid } ?: emptyList()
            val hasNus = serviceUuids.contains(BleConstants.NUS_SERVICE_UUID)

            // Exact identification of Source Node A, Source Node B, and Output Node
            val matchesA = bestName.equals(BleConstants.NODE_A_NAME, ignoreCase = true) ||
                    bestName.contains("Node_A", ignoreCase = true) ||
                    bestName.contains("Node A", ignoreCase = true)

            val matchesB = bestName.equals(BleConstants.NODE_B_NAME, ignoreCase = true) ||
                    bestName.contains("Node_B", ignoreCase = true) ||
                    bestName.contains("Node B", ignoreCase = true)

            val matchesOutput = bestName.equals(BleConstants.OUTPUT_NODE_NAME, ignoreCase = true) ||
                    bestName.contains("FINAL_RECEIVER", ignoreCase = true) ||
                    bestName.contains("Final Receiver", ignoreCase = true) ||
                    bestName.contains("ESP32_FINAL", ignoreCase = true) ||
                    bestName.contains("OUTPUT_NODE", ignoreCase = true) ||
                    bestName.contains("Output Node", ignoreCase = true) ||
                    bestName.contains("Node_D", ignoreCase = true) ||
                    bestName.contains("Node D", ignoreCase = true)

            val candidate = DiscoveredBleDevice(
                name = bestName,
                address = address,
                rssi = rssi,
                matchesNodeA = matchesA,
                matchesNodeB = matchesB,
                matchesOutputNode = matchesOutput,
                hasNusService = hasNus
            )

            val current = _discoveredDevices.value.toMutableList()
            val existingIndex = current.indexOfFirst { it.address == address }
            if (existingIndex >= 0) {
                current[existingIndex] = candidate
            } else {
                current.add(candidate)
            }

            // Sort: prioritize matching target node, then NUS, then RSSI
            val target = _scanTarget.value
            current.sortWith { a, b ->
                val aRank = if (target == SourceNodeId.OUTPUT_NODE) {
                    if (a.matchesOutputNode) 2 else if (a.hasNusService) 1 else 0
                } else {
                    if (a.matchesNodeA || a.matchesNodeB) 2 else if (a.hasNusService) 1 else 0
                }
                val bRank = if (target == SourceNodeId.OUTPUT_NODE) {
                    if (b.matchesOutputNode) 2 else if (b.hasNusService) 1 else 0
                } else {
                    if (b.matchesNodeA || b.matchesNodeB) 2 else if (b.hasNusService) 1 else 0
                }
                if (aRank != bRank) bRank.compareTo(aRank) else b.rssi.compareTo(a.rssi)
            }
            _discoveredDevices.value = current.toList()

            // If scanning specifically for a target node, report to logs when found
            if (target == SourceNodeId.NODE_A && matchesA) {
                nodeA.updateStep(NodeConnectionStep.DEVICE_FOUND)
                addDebugLog("[BLE-A]", "${BleConstants.NODE_A_NAME} discovered ($address, $rssi dBm)")
            } else if (target == SourceNodeId.NODE_B && matchesB) {
                nodeB.updateStep(NodeConnectionStep.DEVICE_FOUND)
                addDebugLog("[BLE-B]", "${BleConstants.NODE_B_NAME} discovered ($address, $rssi dBm)")
            } else if (target == SourceNodeId.OUTPUT_NODE && matchesOutput) {
                outputNode.updateStep(NodeConnectionStep.DEVICE_FOUND)
                addDebugLog("[BLE-OUT]", "${BleConstants.OUTPUT_NODE_NAME} discovered ($address, $rssi dBm)")
            }
        }

        override fun onScanFailed(errorCode: Int) {
            _isScanning.value = false
            addDebugLog("[SCAN]", "BLE Scan failed with code $errorCode", isError = true)
        }
    }

    @SuppressLint("MissingPermission")
    fun startScan(targetNode: SourceNodeId? = null) {
        if (!isBluetoothSupported) {
            addDebugLog("[SCAN]", "Bluetooth not supported on this hardware", isError = true)
            return
        }
        if (!isBluetoothEnabled) {
            addDebugLog("[SCAN]", "Bluetooth is OFF. Please enable Bluetooth.", isError = true)
            return
        }

        _scanTarget.value = targetNode
        _discoveredDevices.value = emptyList()
        _isScanning.value = true

        val targetLabel = when (targetNode) {
            SourceNodeId.NODE_A -> "Source Node A (${BleConstants.NODE_A_NAME})"
            SourceNodeId.NODE_B -> "Source Node B (${BleConstants.NODE_B_NAME})"
            SourceNodeId.OUTPUT_NODE -> "Output Node (${BleConstants.OUTPUT_NODE_NAME})"
            null -> "Source Nodes (A & B)"
        }

        addDebugLog(
            when (targetNode) {
                SourceNodeId.NODE_A -> "[BLE-A]"
                SourceNodeId.NODE_B -> "[BLE-B]"
                SourceNodeId.OUTPUT_NODE -> "[BLE-OUT]"
                null -> "[SCAN]"
            },
            "Scanning for $targetLabel..."
        )

        when (targetNode) {
            SourceNodeId.NODE_A -> nodeA.updateStep(NodeConnectionStep.SCANNING)
            SourceNodeId.NODE_B -> nodeB.updateStep(NodeConnectionStep.SCANNING)
            SourceNodeId.OUTPUT_NODE -> outputNode.updateStep(NodeConnectionStep.SCANNING)
            null -> {}
        }

        try {
            val settings = ScanSettings.Builder()
                .setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY)
                .build()

            // Scan without strict hardware filter to capture scan response names reliably
            bluetoothAdapter?.bluetoothLeScanner?.startScan(null, settings, scanCallback)

            // Auto stop scan after 12 seconds
            scope.launch {
                delay(12000)
                if (_isScanning.value) {
                    stopScan()
                }
            }
        } catch (e: SecurityException) {
            addDebugLog("[SCAN]", "Bluetooth permission denied for scanning", isError = true)
            _isScanning.value = false
        } catch (e: Exception) {
            addDebugLog("[SCAN]", "Scan error: ${e.message}", isError = true)
            _isScanning.value = false
        }
    }

    @SuppressLint("MissingPermission")
    fun stopScan() {
        if (!_isScanning.value) return
        try {
            bluetoothAdapter?.bluetoothLeScanner?.stopScan(scanCallback)
        } catch (_: Exception) {}
        _isScanning.value = false
        addDebugLog("[SCAN]", "Scan stopped")
    }

    @SuppressLint("MissingPermission")
    fun connectNode(targetNode: SourceNodeId, deviceAddress: String) {
        stopScan()
        val device = try {
            bluetoothAdapter?.getRemoteDevice(deviceAddress)
        } catch (_: Exception) {
            null
        }

        if (device == null) {
            addDebugLog(
                when (targetNode) {
                    SourceNodeId.NODE_A -> "[BLE-A]"
                    SourceNodeId.NODE_B -> "[BLE-B]"
                    SourceNodeId.OUTPUT_NODE -> "[BLE-OUT]"
                },
                "Cannot resolve BLE device address: $deviceAddress",
                isError = true
            )
            return
        }

        when (targetNode) {
            SourceNodeId.NODE_A -> nodeA.connect(device)
            SourceNodeId.NODE_B -> nodeB.connect(device)
            SourceNodeId.OUTPUT_NODE -> outputNode.connect(device)
        }
    }

    fun disconnectNode(targetNode: SourceNodeId) {
        when (targetNode) {
            SourceNodeId.NODE_A -> nodeA.disconnect("User disconnected Node A")
            SourceNodeId.NODE_B -> nodeB.disconnect("User disconnected Node B")
            SourceNodeId.OUTPUT_NODE -> outputNode.disconnect("User disconnected Output Node")
        }
    }

    fun disconnectAll() {
        nodeA.disconnect("App closed")
        nodeB.disconnect("App closed")
        outputNode.disconnect("App closed")
    }

    /**
     * Resolves the active node to use based on user selection:
     * - NODE_A -> Node A (must be READY)
     * - NODE_B -> Node B (must be READY)
     * - AUTO -> Node A if ready, otherwise Node B if ready
     */
    fun resolveActiveSourceNode(selection: SourceNodeSelection): BleNodeConnection? {
        return when (selection) {
            SourceNodeSelection.NODE_A -> if (nodeA.status.value.isReady) nodeA else null
            SourceNodeSelection.NODE_B -> if (nodeB.status.value.isReady) nodeB else null
            SourceNodeSelection.AUTO -> {
                if (nodeA.status.value.isReady) nodeA
                else if (nodeB.status.value.isReady) nodeB
                else null
            }
        }
    }

    fun isSendAllowed(selection: SourceNodeSelection): Boolean {
        return resolveActiveSourceNode(selection) != null
    }

    /**
     * Next 16-bit message ID (1001..65535, then wrap)
     */
    private fun getNextMessageId(): Int {
        val next = messageIdCounter.getAndIncrement()
        if (next > 65000) {
            messageIdCounter.set(1001)
        }
        return next
    }

    /**
     * Transmits an emergency JSON message through the chosen source ESP32 node.
     * Fragments into 20-byte frames (9-byte header + max 11-byte payload).
     * Sends sequentially with 3 retries per frame and ACK validation.
     */
    suspend fun transmitEmergencyMessage(
        selection: SourceNodeSelection,
        jsonBase: String,
        onProgress: (part: Int, total: Int) -> Unit
    ): TransmissionResult {
        val target = resolveActiveSourceNode(selection)
            ?: return TransmissionResult.Failure(
                errorMessage = when (selection) {
                    SourceNodeSelection.NODE_A -> "Node A is not ready. Status: ${nodeA.status.value.step.label}"
                    SourceNodeSelection.NODE_B -> "Node B is not ready. Status: ${nodeB.status.value.step.label}"
                    SourceNodeSelection.AUTO -> "No source ESP32 is connected."
                }
            )

        val resolvedSourceId = target.nodeId
        val messageId = getNextMessageId()

        // Ensure "source" in JSON matches the actual physical target
        val finalJson = try {
            val obj = JSONObject(jsonBase)
            obj.put("source", if (resolvedSourceId == SourceNodeId.NODE_A) "NODE_A" else "NODE_B")
            obj.toString()
        } catch (_: Exception) {
            jsonBase
        }

        // Generate 20-byte binary frames
        val frames = BlePacketFramer.createFrames(messageId, finalJson)

        addDebugLog("[SEND]", "Source: ${resolvedSourceId.name}")
        addDebugLog("[SEND]", "Message ID: $messageId")
        addDebugLog("[SEND]", "Total fragments: ${frames.size}")

        val sendResult = target.sendFragmentsSequential(frames, onProgress)

        return when (sendResult) {
            is FragmentSendResult.Success -> {
                val sentLabel = if (resolvedSourceId == SourceNodeId.NODE_A) "Sent to Node A" else "Sent to Node B"
                addDebugLog("[SEND]", "$sentLabel ($messageId)", isSuccess = true)
                TransmissionResult.Success(
                    sourceNode = resolvedSourceId,
                    messageId = messageId,
                    totalFragments = sendResult.totalFragments,
                    statusText = sentLabel,
                    finalJson = finalJson
                )
            }
            is FragmentSendResult.Failure -> {
                addDebugLog("[SEND]", sendResult.message, isError = true)
                TransmissionResult.Failure(
                    errorMessage = sendResult.message,
                    sourceNode = resolvedSourceId
                )
            }
        }
    }

    /**
     * Demo mode simulator: simulates a relay notification from Node B
     */
    fun simulateIncomingRelay(payload: String) {
        scope.launch {
            val relayedMessage = "${BleConstants.RELAYED_PREFIX}$payload\n"
            _incomingDataFlow.emit(relayedMessage)
            addDebugLog("[DEMO]", "Simulated relay packet delivered to receiver")
        }
    }
}

sealed class TransmissionResult {
    data class Success(
        val sourceNode: SourceNodeId,
        val messageId: Int,
        val totalFragments: Int,
        val statusText: String, // e.g. "Sent to Node A"
        val finalJson: String
    ) : TransmissionResult()

    data class Failure(
        val errorMessage: String,
        val sourceNode: SourceNodeId? = null
    ) : TransmissionResult()
}
