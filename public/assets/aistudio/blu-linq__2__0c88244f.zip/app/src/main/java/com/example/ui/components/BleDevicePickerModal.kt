package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bluetooth
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.ble.DiscoveredBleDevice
import com.example.data.ble.SourceNodeId
import com.example.ui.theme.CyberCard
import com.example.ui.theme.CyberCardBorder
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.CyberGreen
import com.example.ui.theme.CyberSurface
import com.example.ui.theme.CyberTextMuted
import com.example.ui.theme.CyberTextPrimary
import com.example.ui.theme.CyberTextSecondary

@Composable
fun BleDevicePickerModal(
    title: String,
    targetNode: SourceNodeId?,
    devices: List<DiscoveredBleDevice>,
    isScanning: Boolean,
    onDeviceSelected: (DiscoveredBleDevice) -> Unit,
    onRescanClick: () -> Unit,
    onDismiss: () -> Unit
) {
    val isForOutputNode = targetNode == SourceNodeId.OUTPUT_NODE
    val primaryNodes = if (isForOutputNode) {
        devices.filter { it.matchesOutputNode }
    } else {
        devices.filter { it.isRecognizedSourceNode }
    }
    val otherDevices = if (isForOutputNode) {
        // Must NOT connect to Node_A_Input, ESP32_NODE_B, or ESP32-C
        devices.filter { !it.matchesOutputNode && !it.matchesNodeA && !it.matchesNodeB && !it.name.contains("Node_A", ignoreCase = true) && !it.name.contains("NODE_B", ignoreCase = true) && !it.name.contains("ESP32-C", ignoreCase = true) }
    } else {
        devices.filter { !it.isRecognizedSourceNode }
    }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.96f)
                .clip(RoundedCornerShape(24.dp))
                .testTag("ble_device_picker_dialog"),
            color = CyberCard,
            tonalElevation = 8.dp
        ) {
            Column(
                modifier = Modifier
                    .padding(20.dp)
                    .fillMaxWidth()
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = title,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = CyberTextPrimary
                        )
                        Text(
                            text = if (isScanning) "Searching for NUS broadcasts..." else "${devices.size} device(s) nearby",
                            style = MaterialTheme.typography.bodySmall,
                            color = CyberTextSecondary
                        )
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = CyberTextSecondary)
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                if (devices.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(160.dp)
                            .background(CyberSurface, RoundedCornerShape(14.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            if (isScanning) {
                                CircularProgressIndicator(color = CyberCyan, modifier = Modifier.size(32.dp))
                                Spacer(modifier = Modifier.height(12.dp))
                                Text(
                                    text = "Scanning nearby BLE devices...",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = CyberTextSecondary
                                )
                            } else {
                                Text(
                                    text = "No ESP32 source nodes found.\nEnsure your ESP32 is powered on.",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = CyberTextMuted,
                                    textAlign = androidx.compose.ui.text.style.TextAlign.Center
                                )
                            }
                        }
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(290.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        if (primaryNodes.isNotEmpty()) {
                            item {
                                Text(
                                    text = if (isForOutputNode) "RECOGNIZED OUTPUT NODE (FINAL TERMINAL)" else "RECOGNIZED SOURCE NODES",
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isForOutputNode) CyberGreen else CyberCyan,
                                    letterSpacing = 1.sp,
                                    modifier = Modifier.padding(vertical = 4.dp)
                                )
                            }
                            items(primaryNodes, key = { it.address }) { dev ->
                                DeviceItemRow(
                                    dev = dev,
                                    isRecommended = true,
                                    onSelect = { onDeviceSelected(dev) }
                                )
                            }
                        }

                        if (otherDevices.isNotEmpty()) {
                            item {
                                Text(
                                    text = "OTHER DETECTED BLE DEVICES",
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = CyberTextMuted,
                                    letterSpacing = 1.sp,
                                    modifier = Modifier.padding(top = 10.dp, bottom = 4.dp)
                                )
                            }
                            items(otherDevices, key = { it.address }) { dev ->
                                DeviceItemRow(
                                    dev = dev,
                                    isRecommended = false,
                                    onSelect = { onDeviceSelected(dev) }
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Button(
                        onClick = onRescanClick,
                        colors = ButtonDefaults.buttonColors(containerColor = CyberSurface, contentColor = CyberTextPrimary),
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(if (isScanning) "Rescan" else "Scan Again", fontSize = 13.sp)
                    }
                }
            }
        }
    }
}

@Composable
private fun DeviceItemRow(
    dev: DiscoveredBleDevice,
    isRecommended: Boolean,
    onSelect: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isRecommended) CyberCyan.copy(alpha = 0.12f) else CyberSurface
        ),
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onSelect() }
            .testTag("discovered_device_${dev.address}")
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(if (isRecommended) CyberCyan else CyberSurface),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    Icons.Default.Bluetooth,
                    contentDescription = null,
                    tint = if (isRecommended) Color.Black else CyberTextSecondary,
                    modifier = Modifier.size(20.dp)
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = dev.name,
                        fontWeight = FontWeight.Bold,
                        color = if (isRecommended) CyberCyan else CyberTextPrimary,
                        style = MaterialTheme.typography.bodyMedium
                    )
                    if (isRecommended) {
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (dev.matchesOutputNode) "OUTPUT NODE" else if (dev.matchesNodeA) "NODE A" else if (dev.matchesNodeB) "NODE B" else "NUS",
                            fontSize = 9.sp,
                            fontWeight = FontWeight.Bold,
                            color = CyberGreen,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                }
                Text(
                    text = "${dev.address} • RSSI: ${dev.rssi} dBm",
                    style = MaterialTheme.typography.labelSmall,
                    color = CyberTextMuted
                )
            }

            Button(
                onClick = onSelect,
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (isRecommended) CyberCyan else CyberCardBorder,
                    contentColor = if (isRecommended) Color.Black else CyberTextPrimary
                ),
                modifier = Modifier.testTag("pair_btn_${dev.address}")
            ) {
                Text("Connect", fontWeight = FontWeight.Bold, fontSize = 12.sp)
            }
        }
    }
}
