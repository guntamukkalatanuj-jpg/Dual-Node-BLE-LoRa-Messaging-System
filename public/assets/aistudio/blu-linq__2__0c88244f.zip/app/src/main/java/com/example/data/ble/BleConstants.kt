package com.example.data.ble

import java.util.UUID

object BleConstants {
    // Nordic UART Service (NUS) exact 128-bit UUIDs
    val NUS_SERVICE_UUID: UUID = UUID.fromString("6E400001-B5A3-F393-E0A9-E50E24DCCA9E")
    val NUS_RX_CHARACTERISTIC_UUID: UUID = UUID.fromString("6E400002-B5A3-F393-E0A9-E50E24DCCA9E")
    val NUS_TX_CHARACTERISTIC_UUID: UUID = UUID.fromString("6E400003-B5A3-F393-E0A9-E50E24DCCA9E")

    // Standard Client Characteristic Configuration Descriptor (CCCD)
    val CCCD_DESCRIPTOR_UUID: UUID = UUID.fromString("00002902-0000-1000-8000-00805F9B34FB")

    // Exact ESP32 BLE Device Names
    const val NODE_A_NAME = "Node_A_Input"
    const val NODE_B_NAME = "ESP32_NODE_B"
    const val OUTPUT_NODE_NAME = "ESP32_FINAL_RECEIVER"

    // Relayed prefix from Node B firmware if acting as receiver
    const val RELAYED_PREFIX = "[Relayed]: "

    // Binary BLE Framing Protocol Constants
    const val MAGIC_BYTE_0: Byte = 0xB1.toByte()
    const val MAGIC_BYTE_1: Byte = 0x01.toByte()
    const val MAX_PAYLOAD_CHUNK_BYTES = 11
    const val HEADER_SIZE_BYTES = 9
    const val MAX_FRAME_SIZE_BYTES = 20 // 9-byte header + 11-byte payload
}
