package com.example.ui.screens

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Cloud
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.Podcasts
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.SignalCellularAlt
import androidx.compose.material.icons.filled.Thermostat
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.ble.BleConstants
import com.example.data.ble.DiscoveredBleDevice
import com.example.data.model.ReceivedMessageEntity
import com.example.ui.components.BleConnectionCard
import com.example.ui.components.BleDevicePickerModal
import com.example.ui.theme.CyberAmber
import com.example.ui.theme.CyberBlue
import com.example.ui.theme.CyberCard
import com.example.ui.theme.CyberCardBorder
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.CyberGreen
import com.example.ui.theme.CyberRed
import com.example.ui.theme.CyberSurface
import com.example.ui.theme.CyberTextMuted
import com.example.ui.theme.CyberTextPrimary
import com.example.ui.theme.CyberTextSecondary
import com.example.ui.viewmodel.BluLinQUiState

@Composable
fun ReceiverScreen(
    state: BluLinQUiState,
    onSearchChange: (String) -> Unit,
    onAcknowledgeAlert: (Long) -> Unit,
    onStartScan: () -> Unit,
    onStopScan: () -> Unit,
    onSelectDevice: (deviceAddress: String, targetNode: com.example.data.ble.SourceNodeId) -> Unit,
    onDisconnectBle: () -> Unit,
    onClearHistory: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var showDevicePicker by remember { mutableStateOf(false) }

    // BLE permission request launcher
    val blePermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        val granted = permissions.values.all { it }
        if (granted) {
            onStartScan()
            showDevicePicker = true
        }
    }

    fun requestBleAndScan() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            blePermissionLauncher.launch(
                arrayOf(
                    Manifest.permission.BLUETOOTH_SCAN,
                    Manifest.permission.BLUETOOTH_CONNECT
                )
            )
        } else {
            blePermissionLauncher.launch(
                arrayOf(
                    Manifest.permission.ACCESS_FINE_LOCATION,
                    Manifest.permission.BLUETOOTH,
                    Manifest.permission.BLUETOOTH_ADMIN
                )
            )
        }
    }

    fun openInMap(lat: Double, lng: Double, label: String) {
        try {
            val uri = Uri.parse("geo:$lat,$lng?q=$lat,$lng($label)")
            val intent = Intent(Intent.ACTION_VIEW, uri)
            intent.setPackage("com.google.android.apps.maps")
            if (intent.resolveActivity(context.packageManager) != null) {
                context.startActivity(intent)
            } else {
                // Fallback to any map handler or browser
                val fallbackIntent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/maps/search/?api=1&query=$lat,$lng"))
                context.startActivity(fallbackIntent)
            }
        } catch (_: Exception) {
            val webIntent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/maps/search/?api=1&query=$lat,$lng"))
            context.startActivity(webIntent)
        }
    }

    val latest = state.latestReceivedMessage

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .testTag("receiver_screen"),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Section: Receivers Header
        item {
            Column {
                Text(
                    text = "RECEIVER",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold,
                    color = CyberTextMuted,
                    letterSpacing = 1.sp
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                    text = "Final Terminal • Receives LoRa broadcasts from Gateway C",
                    style = MaterialTheme.typography.bodySmall,
                    color = CyberTextSecondary
                )
            }
        }

        // 1. Connection Status Card for OUTPUT NODE
        item {
            BleConnectionCard(
                status = state.outputNodeStatus,
                isDemoMode = state.isDemoMode,
                onConnectClick = { requestBleAndScan() },
                onDisconnectClick = onDisconnectBle
            )
        }

        // 2. Incoming Emergency Alert Card
        item {
            if (latest != null) {
                val isEmergency = latest.isEmergency
                val containerBg = if (isEmergency && !latest.isAcknowledged) CyberRed.copy(alpha = 0.2f) else CyberCard
                val borderColor = if (isEmergency && !latest.isAcknowledged) CyberRed else CyberCardBorder

                Card(
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = containerBg),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, borderColor, RoundedCornerShape(20.dp))
                        .testTag("incoming_alert_card")
                ) {
                    Column(modifier = Modifier.padding(18.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                if (isEmergency) {
                                    Icon(Icons.Default.Warning, contentDescription = null, tint = CyberRed, modifier = Modifier.size(20.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = "🚨 EMERGENCY ALERT",
                                        style = MaterialTheme.typography.labelMedium,
                                        fontWeight = FontWeight.Black,
                                        color = CyberRed,
                                        letterSpacing = 1.sp
                                    )
                                } else {
                                    Text(
                                        text = "INCOMING ALERT",
                                        style = MaterialTheme.typography.labelMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = CyberCyan,
                                        letterSpacing = 1.sp
                                    )
                                }
                            }

                            Text(
                                text = latest.formattedDateTime(),
                                style = MaterialTheme.typography.labelSmall,
                                color = CyberTextMuted,
                                fontFamily = FontFamily.Monospace
                            )
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        // Large Message Text Display
                        Text(
                            text = latest.messageText,
                            style = MaterialTheme.typography.headlineMedium,
                            fontWeight = FontWeight.Black,
                            color = if (isEmergency) CyberRed else CyberTextPrimary,
                            letterSpacing = 1.sp
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        // Location details if present
                        if (latest.latitude != null && latest.longitude != null) {
                            Card(
                                shape = RoundedCornerShape(12.dp),
                                colors = CardDefaults.cardColors(containerColor = CyberSurface),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(12.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = "LOCATION",
                                            style = MaterialTheme.typography.labelSmall,
                                            fontWeight = FontWeight.Bold,
                                            color = CyberCyan,
                                            fontFamily = FontFamily.Monospace
                                        )
                                        if (latest.accuracy != null) {
                                            Text(
                                                text = "Accuracy: ±${latest.accuracy.toInt()}m",
                                                style = MaterialTheme.typography.labelSmall,
                                                color = CyberTextMuted,
                                                fontFamily = FontFamily.Monospace
                                            )
                                        }
                                    }

                                    Spacer(modifier = Modifier.height(4.dp))

                                    Text(
                                        text = "Lat: ${String.format(java.util.Locale.US, "%.6f", latest.latitude)}\nLng: ${String.format(java.util.Locale.US, "%.6f", latest.longitude)}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = CyberTextPrimary,
                                        fontFamily = FontFamily.Monospace
                                    )

                                    Spacer(modifier = Modifier.height(8.dp))

                                    Button(
                                        onClick = { openInMap(latest.latitude, latest.longitude, "Emergency: ${latest.messageText}") },
                                        colors = ButtonDefaults.buttonColors(containerColor = CyberBlue, contentColor = Color.White),
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(40.dp)
                                            .testTag("open_in_map_button")
                                    ) {
                                        Icon(Icons.Default.Map, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text("OPEN IN MAP", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                    }
                                }
                            }
                        }

                        // Weather telemetry if present
                        if (latest.temperature != null) {
                            Spacer(modifier = Modifier.height(8.dp))
                            Card(
                                shape = RoundedCornerShape(12.dp),
                                colors = CardDefaults.cardColors(containerColor = CyberSurface),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(12.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Column {
                                        Text(text = "WEATHER", style = MaterialTheme.typography.labelSmall, color = CyberCyan, fontFamily = FontFamily.Monospace)
                                        Text(text = "${String.format(java.util.Locale.US, "%.1f", latest.temperature)}°C", style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold, color = CyberTextPrimary)
                                    }
                                    Column {
                                        Text(text = "FEELS LIKE", style = MaterialTheme.typography.labelSmall, color = CyberTextMuted, fontFamily = FontFamily.Monospace)
                                        Text(text = "${String.format(java.util.Locale.US, "%.1f", latest.feelsLike ?: latest.temperature)}°C", style = MaterialTheme.typography.bodySmall, color = CyberTextPrimary)
                                    }
                                    Column {
                                        Text(text = "HUMIDITY", style = MaterialTheme.typography.labelSmall, color = CyberTextMuted, fontFamily = FontFamily.Monospace)
                                        Text(text = "${latest.humidity ?: 0}%", style = MaterialTheme.typography.bodySmall, color = CyberTextPrimary)
                                    }
                                    Column {
                                        Text(text = "CONDITION", style = MaterialTheme.typography.labelSmall, color = CyberTextMuted, fontFamily = FontFamily.Monospace)
                                        Text(text = latest.weatherCondition ?: "Clear", style = MaterialTheme.typography.bodySmall, color = CyberTextPrimary)
                                    }
                                }
                            }
                        }

                        // Acknowledge Button for emergency alerts
                        if (isEmergency && !latest.isAcknowledged) {
                            Spacer(modifier = Modifier.height(14.dp))
                            Button(
                                onClick = { onAcknowledgeAlert(latest.id) },
                                colors = ButtonDefaults.buttonColors(containerColor = CyberAmber, contentColor = Color.Black),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(48.dp)
                                    .testTag("acknowledge_alert_button")
                            ) {
                                Icon(Icons.Default.Check, contentDescription = null)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("ACKNOWLEDGE ALERT", fontWeight = FontWeight.Black)
                            }
                        }
                    }
                }
            } else {
                // Empty state
                Card(
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = CyberCard),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, CyberCardBorder, RoundedCornerShape(20.dp))
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            Icons.Default.Podcasts,
                            contentDescription = null,
                            tint = CyberTextMuted,
                            modifier = Modifier.size(40.dp)
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = "No message received",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = CyberTextSecondary
                        )
                        Text(
                            text = "Waiting for relayed transmissions via LoRa from Gateway C...",
                            style = MaterialTheme.typography.bodySmall,
                            color = CyberTextMuted
                        )
                    }
                }
            }
        }

        // 3. Signal Status Card
        item {
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = CyberCard),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, CyberCardBorder, RoundedCornerShape(20.dp))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "OUTPUT NODE SIGNAL STATUS",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = CyberTextMuted,
                        letterSpacing = 1.sp
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        SignalMetric(
                            label = "BLE Link",
                            value = if (state.outputNodeStatus.bleLinkConnected || state.isDemoMode) "Connected" else "Disconnected",
                            isOk = state.outputNodeStatus.bleLinkConnected || state.isDemoMode
                        )
                        SignalMetric(
                            label = "Output Node",
                            value = if (state.outputNodeStatus.isReady || state.isDemoMode) "Ready" else state.outputNodeStatus.step.label,
                            isOk = state.outputNodeStatus.isReady || state.isDemoMode
                        )
                        SignalMetric(
                            label = "RSSI",
                            value = if (state.outputNodeStatus.rssi != null) "${state.outputNodeStatus.rssi} dBm" else "—",
                            isOk = state.outputNodeStatus.rssi != null || state.isDemoMode
                        )
                    }
                }
            }
        }

        // 4. Received Messages History Section
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "RECEIVED MESSAGES (${state.receivedMessages.size})",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold,
                    color = CyberTextMuted,
                    letterSpacing = 1.sp
                )

                if (state.receivedMessages.isNotEmpty()) {
                    TextButton(onClick = onClearHistory) {
                        Icon(Icons.Default.Delete, contentDescription = "Clear", tint = CyberTextMuted, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Clear", color = CyberTextMuted, fontSize = 12.sp)
                    }
                }
            }
        }

        // Search Bar
        item {
            OutlinedTextField(
                value = state.searchQuery,
                onValueChange = onSearchChange,
                placeholder = { Text("Search received alerts...", color = CyberTextMuted) },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = CyberTextSecondary) },
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = CyberCyan,
                    unfocusedBorderColor = CyberCardBorder,
                    focusedTextColor = CyberTextPrimary,
                    unfocusedTextColor = CyberTextPrimary,
                    cursorColor = CyberCyan
                ),
                shape = RoundedCornerShape(12.dp),
                singleLine = true,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("receiver_search_input")
            )
        }

        if (state.receivedMessages.isEmpty()) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 24.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "No received messages in log.",
                        style = MaterialTheme.typography.bodySmall,
                        color = CyberTextMuted
                    )
                }
            }
        } else {
            items(state.receivedMessages, key = { it.id }) { msg ->
                ReceivedMessageRow(
                    message = msg,
                    onOpenMap = { lat, lng -> openInMap(lat, lng, msg.messageText) }
                )
            }
        }
    }

    // Modal: BLE Device Picker for OUTPUT NODE (ESP32_FINAL_RECEIVER)
    if (showDevicePicker) {
        BleDevicePickerModal(
            title = "Connect to Output Node (${BleConstants.OUTPUT_NODE_NAME})",
            targetNode = com.example.data.ble.SourceNodeId.OUTPUT_NODE,
            devices = state.discoveredDevices,
            isScanning = state.isScanning,
            onDeviceSelected = { dev ->
                onSelectDevice(dev.address, com.example.data.ble.SourceNodeId.OUTPUT_NODE)
                showDevicePicker = false
            },
            onRescanClick = onStartScan,
            onDismiss = {
                onStopScan()
                showDevicePicker = false
            }
        )
    }
}

@Composable
private fun SignalMetric(label: String, value: String, isOk: Boolean) {
    Column {
        Text(text = label, style = MaterialTheme.typography.labelSmall, color = CyberTextMuted)
        Text(
            text = value,
            style = MaterialTheme.typography.bodySmall,
            fontWeight = FontWeight.Bold,
            color = if (isOk) CyberGreen else CyberRed,
            fontFamily = FontFamily.Monospace
        )
    }
}

@Composable
fun ReceivedMessageRow(
    message: ReceivedMessageEntity,
    onOpenMap: (Double, Double) -> Unit
) {
    val isEmergency = message.isEmergency

    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = CyberCard),
        modifier = Modifier
            .fillMaxWidth()
            .border(
                1.dp,
                if (isEmergency) CyberRed.copy(alpha = 0.5f) else CyberCardBorder,
                RoundedCornerShape(14.dp)
            )
            .testTag("received_message_${message.id}")
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    if (isEmergency) {
                        Text(
                            text = "EMERGENCY",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = CyberRed,
                            fontFamily = FontFamily.Monospace,
                            modifier = Modifier
                                .clip(RoundedCornerShape(4.dp))
                                .background(CyberRed.copy(alpha = 0.2f))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                    }
                    Text(
                        text = message.messageText,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = if (isEmergency) CyberRed else CyberTextPrimary
                    )
                }

                Text(
                    text = message.formattedDateTime(),
                    style = MaterialTheme.typography.labelSmall,
                    color = CyberTextMuted,
                    fontFamily = FontFamily.Monospace
                )
            }

            if (message.latitude != null && message.longitude != null) {
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "GPS: ${String.format(java.util.Locale.US, "%.5f, %.5f", message.latitude, message.longitude)}",
                        style = MaterialTheme.typography.labelSmall,
                        color = CyberTextMuted,
                        fontFamily = FontFamily.Monospace
                    )
                    Text(
                        text = "Open Map ↗",
                        style = MaterialTheme.typography.labelSmall,
                        color = CyberCyan,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.clickable { onOpenMap(message.latitude, message.longitude) }
                    )
                }
            }

            if (message.temperature != null) {
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Weather: ${String.format(java.util.Locale.US, "%.1f", message.temperature)}°C • ${message.weatherCondition ?: "Clear"}",
                    style = MaterialTheme.typography.labelSmall,
                    color = CyberTextMuted
                )
            }
        }
    }
}
