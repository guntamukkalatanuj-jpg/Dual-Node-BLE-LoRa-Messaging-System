package com.example.data.ble

import android.annotation.SuppressLint
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothGatt
import android.bluetooth.BluetoothGattCallback
import android.bluetooth.BluetoothGattCharacteristic
import android.bluetooth.BluetoothGattDescriptor
import android.bluetooth.BluetoothProfile
import android.content.Context
import android.os.Build
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull

class BleNodeConnection(
    private val context: Context,
    val nodeId: SourceNodeId,
    val expectedName: String,
    private val scope: CoroutineScope,
    private val onLog: (tag: String, message: String, isError: Boolean, isSuccess: Boolean) -> Unit
) {
    val tag = when (nodeId) {
        SourceNodeId.NODE_A -> "BLE-A"
        SourceNodeId.NODE_B -> "BLE-B"
        SourceNodeId.OUTPUT_NODE -> "BLE-OUT"
    }

    private var bluetoothGatt: BluetoothGatt? = null
    private var rxCharacteristic: BluetoothGattCharacteristic? = null
    private var txCharacteristic: BluetoothGattCharacteristic? = null

    private val _status = MutableStateFlow(
        NodeConnectionStatus(
            nodeId = nodeId,
            expectedName = expectedName,
            connectedDeviceName = "Not connected",
            step = NodeConnectionStep.DISCONNECTED
        )
    )
    val status: StateFlow<NodeConnectionStatus> = _status.asStateFlow()

    // Shared flow for incoming text notifications / ACKs from this node
    private val _incomingNotifications = MutableSharedFlow<String>(extraBufferCapacity = 64)
    val incomingNotifications: SharedFlow<String> = _incomingNotifications.asSharedFlow()

    // Write synchronization lock
    private val writeMutex = Mutex()
    private var writeCompletionDeferred: CompletableDeferred<Boolean>? = null
    private var ackDeferred: CompletableDeferred<String>? = null

    private fun log(message: String, isError: Boolean = false, isSuccess: Boolean = false) {
        onLog("[$tag]", message, isError, isSuccess)
    }

    fun updateStep(step: NodeConnectionStep, errorMsg: String? = null) {
        val current = _status.value
        _status.value = current.copy(
            step = step,
            errorMessage = errorMsg,
            isReady = (step == NodeConnectionStep.READY)
        )
    }

    @SuppressLint("MissingPermission")
    fun connect(device: BluetoothDevice) {
        disconnect()

        val devName = try {
            device.name ?: expectedName
        } catch (_: SecurityException) {
            expectedName
        }

        _status.value = _status.value.copy(
            connectedDeviceName = devName,
            deviceAddress = device.address,
            step = NodeConnectionStep.CONNECTING,
            bleLinkConnected = false,
            gattReady = false,
            nusFound = false,
            rxReady = false,
            txReady = false,
            notificationsReady = false,
            isReady = false,
            errorMessage = null
        )

        log("Connecting to $devName (${device.address})...")

        try {
            bluetoothGatt = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                device.connectGatt(context, false, gattCallback, BluetoothDevice.TRANSPORT_LE)
            } else {
                device.connectGatt(context, false, gattCallback)
            }
        } catch (e: SecurityException) {
            handleError("Bluetooth permission denied")
        } catch (e: Exception) {
            handleError("Connection error: ${e.message}")
        }
    }

    @SuppressLint("MissingPermission")
    fun disconnect(reason: String = "Disconnected") {
        try {
            bluetoothGatt?.disconnect()
            bluetoothGatt?.close()
        } catch (_: Exception) {}

        bluetoothGatt = null
        rxCharacteristic = null
        txCharacteristic = null

        _status.value = NodeConnectionStatus(
            nodeId = nodeId,
            expectedName = expectedName,
            connectedDeviceName = "Not connected",
            step = NodeConnectionStep.DISCONNECTED,
            errorMessage = null
        )
        log("Disconnected ($reason)")
    }

    private fun handleError(message: String) {
        log(message, isError = true)
        rxCharacteristic = null
        txCharacteristic = null
        try {
            bluetoothGatt?.disconnect()
            bluetoothGatt?.close()
        } catch (_: Exception) {}
        bluetoothGatt = null

        _status.value = _status.value.copy(
            step = NodeConnectionStep.ERROR,
            errorMessage = message,
            bleLinkConnected = false,
            gattReady = false,
            nusFound = false,
            rxReady = false,
            txReady = false,
            notificationsReady = false,
            isReady = false
        )
    }

    private val gattCallback = object : BluetoothGattCallback() {
        @SuppressLint("MissingPermission")
        override fun onConnectionStateChange(gatt: BluetoothGatt, status: Int, newState: Int) {
            if (status != BluetoothGatt.GATT_SUCCESS || newState == BluetoothProfile.STATE_DISCONNECTED) {
                scope.launch {
                    handleError("ESP32 connection lost. Check hardware power.")
                }
                return
            }

            if (newState == BluetoothProfile.STATE_CONNECTED) {
                scope.launch {
                    log("GATT connected")
                    _status.value = _status.value.copy(
                        step = NodeConnectionStep.CONNECTED,
                        bleLinkConnected = true,
                        gattReady = true
                    )

                    // Request MTU up to 512 for stability
                    try {
                        gatt.requestMtu(512)
                    } catch (_: Exception) {}

                    delay(250)

                    log("Discovering services...")
                    _status.value = _status.value.copy(
                        step = NodeConnectionStep.DISCOVERING_SERVICES
                    )
                    gatt.discoverServices()
                }
            }
        }

        @SuppressLint("MissingPermission")
        override fun onServicesDiscovered(gatt: BluetoothGatt, status: Int) {
            if (status != BluetoothGatt.GATT_SUCCESS) {
                scope.launch {
                    handleError("Service discovery failed (status $status)")
                }
                return
            }

            scope.launch {
                log("Services discovered")
                val nusService = gatt.getService(BleConstants.NUS_SERVICE_UUID)
                if (nusService == null) {
                    handleError("NUS service (${BleConstants.NUS_SERVICE_UUID}) not found")
                    return@launch
                }

                log("NUS service found")
                _status.value = _status.value.copy(
                    nusFound = true,
                    step = NodeConnectionStep.NUS_FOUND
                )

                // Locate RX Characteristic
                val rx = nusService.getCharacteristic(BleConstants.NUS_RX_CHARACTERISTIC_UUID)
                if (rx == null) {
                    handleError("NUS RX characteristic not found")
                    return@launch
                }
                val rxCanWrite = (rx.properties and (BluetoothGattCharacteristic.PROPERTY_WRITE or BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE)) != 0
                if (!rxCanWrite) {
                    handleError("NUS RX characteristic does not support WRITE")
                    return@launch
                }
                rxCharacteristic = rx
                log("RX characteristic found & write ready")
                _status.value = _status.value.copy(
                    rxReady = true,
                    step = NodeConnectionStep.RX_FOUND
                )

                // Locate TX Characteristic
                val tx = nusService.getCharacteristic(BleConstants.NUS_TX_CHARACTERISTIC_UUID)
                if (tx == null) {
                    handleError("NUS TX characteristic not found")
                    return@launch
                }
                val txCanNotify = (tx.properties and BluetoothGattCharacteristic.PROPERTY_NOTIFY) != 0
                if (!txCanNotify) {
                    handleError("NUS TX characteristic does not support NOTIFY")
                    return@launch
                }
                txCharacteristic = tx
                log("TX characteristic found")
                _status.value = _status.value.copy(
                    txReady = true,
                    step = NodeConnectionStep.TX_FOUND
                )

                // Enable notifications on TX
                val notifySuccess = gatt.setCharacteristicNotification(tx, true)
                val descriptor = tx.getDescriptor(BleConstants.CCCD_DESCRIPTOR_UUID)
                if (descriptor != null) {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                        gatt.writeDescriptor(descriptor, BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE)
                    } else {
                        @Suppress("DEPRECATION")
                        descriptor.value = BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE
                        @Suppress("DEPRECATION")
                        gatt.writeDescriptor(descriptor)
                    }
                }

                delay(150)
                log("Notifications enabled")
                _status.value = _status.value.copy(
                    notificationsReady = notifySuccess,
                    step = NodeConnectionStep.NOTIFICATIONS_ENABLED
                )

                delay(100)
                // Both RX and TX are verified and notifications enabled -> READY!
                _status.value = _status.value.copy(
                    step = NodeConnectionStep.READY,
                    isReady = true
                )
                log("READY", isSuccess = true)

                // Read RSSI
                try {
                    gatt.readRemoteRssi()
                } catch (_: Exception) {}
            }
        }

        override fun onCharacteristicWrite(
            gatt: BluetoothGatt,
            characteristic: BluetoothGattCharacteristic,
            status: Int
        ) {
            val success = (status == BluetoothGatt.GATT_SUCCESS)
            writeCompletionDeferred?.complete(success)
        }

        @Deprecated("Deprecated in Java")
        override fun onCharacteristicChanged(
            gatt: BluetoothGatt,
            characteristic: BluetoothGattCharacteristic
        ) {
            if (characteristic.uuid == BleConstants.NUS_TX_CHARACTERISTIC_UUID) {
                val data = characteristic.value ?: return
                val text = String(data, Charsets.UTF_8)
                handleIncomingNotification(text)
            }
        }

        override fun onCharacteristicChanged(
            gatt: BluetoothGatt,
            characteristic: BluetoothGattCharacteristic,
            value: ByteArray
        ) {
            if (characteristic.uuid == BleConstants.NUS_TX_CHARACTERISTIC_UUID) {
                val text = String(value, Charsets.UTF_8)
                handleIncomingNotification(text)
            }
        }

        override fun onReadRemoteRssi(gatt: BluetoothGatt, rssi: Int, status: Int) {
            if (status == BluetoothGatt.GATT_SUCCESS) {
                _status.value = _status.value.copy(rssi = rssi)
            }
        }
    }

    private fun handleIncomingNotification(text: String) {
        scope.launch {
            _incomingNotifications.emit(text)
            ackDeferred?.complete(text)
        }
    }

    @SuppressLint("MissingPermission")
    suspend fun sendFrame(frame: BlePacketFramer.BleFrame): Boolean = withContext(Dispatchers.IO) {
        val gatt = bluetoothGatt ?: return@withContext false
        val rx = rxCharacteristic ?: return@withContext false

        if (!_status.value.isReady) {
            return@withContext false
        }

        val frameBytes = frame.toByteArray()
        val completion = CompletableDeferred<Boolean>()
        writeCompletionDeferred = completion

        try {
            val writeType = if ((rx.properties and BluetoothGattCharacteristic.PROPERTY_WRITE_NO_RESPONSE) != 0) {
                BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE
            } else {
                BluetoothGattCharacteristic.WRITE_TYPE_DEFAULT
            }

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                gatt.writeCharacteristic(rx, frameBytes, writeType)
            } else {
                @Suppress("DEPRECATION")
                rx.value = frameBytes
                @Suppress("DEPRECATION")
                rx.writeType = writeType
                @Suppress("DEPRECATION")
                gatt.writeCharacteristic(rx)
            }

            if (writeType == BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE) {
                delay(30)
                return@withContext true
            }

            // Await write callback with 1500ms timeout
            val writeResult = withTimeoutOrNull(1500) {
                completion.await()
            } ?: false

            return@withContext writeResult
        } catch (_: Exception) {
            return@withContext false
        }
    }

    /**
     * Sends fragments sequentially with 3 retries per fragment, checking write completion and optional ACK.
     */
    suspend fun sendFragmentsSequential(
        frames: List<BlePacketFramer.BleFrame>,
        onProgress: (part: Int, total: Int) -> Unit
    ): FragmentSendResult = writeMutex.withLock {
        withContext(Dispatchers.IO) {
            val total = frames.size
            val messageId = frames.firstOrNull()?.messageId ?: 0

            log("[SEND] Starting transmission to $expectedName")
            log("[SEND] Message ID: $messageId, Total fragments: $total")

            for (frame in frames) {
                val part = frame.partIndex
                var attempts = 0
                var success = false

                while (attempts < 3 && !success) {
                    attempts++
                    if (attempts > 1) {
                        log("[SEND] Retrying fragment $part/$total (Attempt $attempts/3)...")
                        delay(120)
                    } else {
                        log("[SEND] Fragment $part/$total")
                    }

                    // Prepare ACK listener if firmware responds with ACK
                    val pendingAck = CompletableDeferred<String>()
                    ackDeferred = pendingAck

                    val writeOk = sendFrame(frame)
                    if (!writeOk) {
                        log("[SEND] Fragment $part write failed", isError = true)
                        continue
                    }

                    // Wait briefly for optional ACK from TX notification (300ms window)
                    val receivedAck = withTimeoutOrNull(300) {
                        pendingAck.await()
                    }

                    if (receivedAck != null && BlePacketFramer.checkIsAck(receivedAck, messageId, part)) {
                        log("[SEND] Fragment $part acknowledged ($receivedAck)")
                    } else {
                        // Write completed successfully
                        delay(25)
                    }

                    success = true
                    onProgress(part, total)
                }

                if (!success) {
                    val errMsg = "Message transmission failed at fragment $part/$total."
                    log("[SEND] $errMsg", isError = true)
                    return@withContext FragmentSendResult.Failure(part, total, errMsg)
                }
            }

            log("[SEND] All $total fragments sent to $expectedName", isSuccess = true)
            return@withContext FragmentSendResult.Success(total)
        }
    }
}

sealed class FragmentSendResult {
    data class Success(val totalFragments: Int) : FragmentSendResult()
    data class Failure(val failedFragment: Int, val totalFragments: Int, val message: String) : FragmentSendResult()
}
