package com.example.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.data.model.ReceivedMessageEntity
import com.example.data.model.TransmissionLogEntity

@Database(
    entities = [TransmissionLogEntity::class, ReceivedMessageEntity::class],
    version = 2,
    exportSchema = false
)
abstract class BluLinQDatabase : RoomDatabase() {
    abstract fun transmissionLogDao(): TransmissionLogDao
    abstract fun receivedMessageDao(): ReceivedMessageDao

    companion object {
        @Volatile
        private var INSTANCE: BluLinQDatabase? = null

        fun getDatabase(context: Context): BluLinQDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    BluLinQDatabase::class.java,
                    "blulinq_emergency_database"
                )
                    .fallbackToDestructiveMigration()
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
