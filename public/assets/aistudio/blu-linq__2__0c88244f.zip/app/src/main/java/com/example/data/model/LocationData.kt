package com.example.data.model

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class LocationData(
    val latitude: Double,
    val longitude: Double,
    val accuracy: Float,
    val timestamp: Long = System.currentTimeMillis()
) {
    fun formattedCoordinates(): String = String.format(Locale.US, "%.6f, %.6f", latitude, longitude)

    fun formattedAccuracy(): String = String.format(Locale.US, "±%.1f m", accuracy)

    fun formattedTimestamp(): String {
        val sdf = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())
        return sdf.format(Date(timestamp))
    }
}
