package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Entity(tableName = "received_messages")
data class ReceivedMessageEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val sourceNode: String = "NODE A", // "NODE A" (0x01) or "NODE B" (0x02)
    val messageId: String = "",
    val timestamp: Long = System.currentTimeMillis(),
    val messageText: String,
    val latitude: Double? = null,
    val longitude: Double? = null,
    val accuracy: Float? = null,
    val temperature: Double? = null,
    val feelsLike: Double? = null,
    val humidity: Int? = null,
    val windSpeed: Double? = null,
    val weatherCondition: String? = null,
    val rssi: Int? = null,
    val connectionStatus: String = "CONNECTED",
    val isAcknowledged: Boolean = false,
    val rawRelayedData: String = ""
) {
    val isEmergency: Boolean
        get() {
            val upper = messageText.trim().uppercase()
            return upper == "HELP" || upper == "SOS" || upper == "FIRE" || upper == "MEDIC" ||
                    upper.contains("EMERGENCY") || upper.contains("DANGER") || upper.contains("MAYDAY")
        }

    fun formattedDate(): String {
        val sdf = SimpleDateFormat("dd MMM yyyy", Locale.getDefault())
        return sdf.format(Date(timestamp))
    }

    fun formattedTime(): String {
        val sdf = SimpleDateFormat("HH:mm:ss", Locale.getDefault())
        return sdf.format(Date(timestamp))
    }

    fun formattedDateTime(): String {
        val sdf = SimpleDateFormat("dd MMM yyyy HH:mm:ss", Locale.getDefault())
        return sdf.format(Date(timestamp))
    }
}
