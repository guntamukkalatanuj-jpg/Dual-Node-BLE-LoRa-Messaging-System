package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val DarkColorScheme = darkColorScheme(
    primary = BluPrimary,
    onPrimary = BluOnPrimary,
    primaryContainer = BluPrimaryContainer,
    onPrimaryContainer = BluOnPrimaryContainer,
    secondary = BluSecondary,
    onSecondary = BluOnSecondary,
    secondaryContainer = BluSecondaryContainer,
    onSecondaryContainer = BluOnSecondaryContainer,
    tertiary = BluTertiary,
    onTertiary = BluOnTertiary,
    tertiaryContainer = BluTertiaryContainer,
    onTertiaryContainer = BluOnTertiaryContainer,
    background = BluBackground,
    onBackground = BluOnBackground,
    surface = BluSurface,
    onSurface = BluOnSurface,
    surfaceVariant = BluSurfaceVariant,
    onSurfaceVariant = BluOnSurfaceVariant,
    outline = BluOutline,
    error = CyberRed
)

@Composable
fun BluLinQTheme(
    content: @Composable () -> Unit
) {
    // Dedicated Dark Cyber / Telemetry theme as specified
    MaterialTheme(
        colorScheme = DarkColorScheme,
        typography = Typography,
        content = content
    )
}

@Composable
fun MyApplicationTheme(
    content: @Composable () -> Unit
) = BluLinQTheme(content = content)
