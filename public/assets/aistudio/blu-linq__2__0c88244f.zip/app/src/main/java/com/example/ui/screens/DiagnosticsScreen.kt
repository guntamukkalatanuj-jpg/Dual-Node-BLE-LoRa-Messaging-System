package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AltRoute
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.ble.BleConstants
import com.example.data.ble.BleDiagnostics
import com.example.data.ble.NodeConnectionStatus
import com.example.ui.theme.CyberAmber
import com.example.ui.theme.CyberBlue
import com.example.ui.theme.CyberCard
import com.example.ui.theme.CyberCardBorder
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.CyberGreen
import com.example.ui.theme.CyberRed
import com.example.ui.theme.CyberSurface
import com.example.ui.theme.CyberTextMuted
import com.example.ui.theme.CyberTextPrimary
import com.example.ui.theme.CyberTextSecondary

@Composable
fun DiagnosticsScreen(
    diagnostics: BleDiagnostics,
    isDemoMode: Boolean,
    modifier: Modifier = Modifier
) {
    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .testTag("diagnostics_screen"),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // 1. Header Card
        item {
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = CyberCard),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, CyberCardBorder, RoundedCornerShape(20.dp))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(18.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(48.dp)
                            .clip(CircleShape)
                            .background(CyberCyan.copy(alpha = 0.15f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.Memory, contentDescription = null, tint = CyberCyan, modifier = Modifier.size(26.dp))
                    }
                    Spacer(modifier = Modifier.width(14.dp))
                    Column {
                        Text(
                            text = "BLE & TELEMETRY DIAGNOSTICS",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Black,
                            color = CyberTextPrimary,
                            letterSpacing = 1.sp
                        )
                        Text(
                            text = if (isDemoMode) "Demo Simulation Mode Active" else "4-ESP32 Mesh Protocol Diagnostics",
                            style = MaterialTheme.typography.bodySmall,
                            color = if (isDemoMode) CyberAmber else CyberGreen
                        )
                    }
                }
            }
        }

        // 2. Node A Diagnostics
        item {
            NodeDiagnosticsCard(title = "SOURCE NODE A (${BleConstants.NODE_A_NAME})", status = diagnostics.nodeAStatus, isDemoMode = isDemoMode)
        }

        // 3. Node B Diagnostics
        item {
            NodeDiagnosticsCard(title = "SOURCE NODE B (${BleConstants.NODE_B_NAME})", status = diagnostics.nodeBStatus, isDemoMode = isDemoMode)
        }

        // 4. Output Node Diagnostics
        item {
            NodeDiagnosticsCard(title = "OUTPUT NODE (${BleConstants.OUTPUT_NODE_NAME} • Final Terminal)", status = diagnostics.outputNodeStatus, isDemoMode = isDemoMode)
        }

        // 5. Exact Firmware UUIDs Card
        item {
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = CyberCard),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, CyberCardBorder, RoundedCornerShape(20.dp))
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Text(
                        text = "FIRMWARE PROTOCOL SPECIFICATION",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = CyberTextMuted,
                        letterSpacing = 1.sp
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    UuidDisplayBlock("NUS SERVICE UUID", BleConstants.NUS_SERVICE_UUID.toString())
                    Spacer(modifier = Modifier.height(8.dp))
                    UuidDisplayBlock("NUS RX CHARACTERISTIC UUID (WRITE)", BleConstants.NUS_RX_CHARACTERISTIC_UUID.toString())
                    Spacer(modifier = Modifier.height(8.dp))
                    UuidDisplayBlock("NUS TX CHARACTERISTIC UUID (NOTIFY)", BleConstants.NUS_TX_CHARACTERISTIC_UUID.toString())
                    Spacer(modifier = Modifier.height(8.dp))
                    UuidDisplayBlock("SOURCE NODE A ADVERTISED NAME", BleConstants.NODE_A_NAME)
                    Spacer(modifier = Modifier.height(8.dp))
                    UuidDisplayBlock("SOURCE NODE B ADVERTISED NAME", BleConstants.NODE_B_NAME)
                    Spacer(modifier = Modifier.height(8.dp))
                    UuidDisplayBlock("OUTPUT NODE ADVERTISED NAME", BleConstants.OUTPUT_NODE_NAME)
                    Spacer(modifier = Modifier.height(8.dp))
                    UuidDisplayBlock("BINARY FRAMING SPEC", "0xB1 0x01 [MsgId 16b] [Part 16b] [Total 16b] [Len 8b] [Payload ≤11b]")
                }
            }
        }

        // 6. 4-ESP32 Architecture Diagram Card
        item {
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = CyberCard),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, CyberCardBorder, RoundedCornerShape(20.dp))
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Text(
                        text = "4-ESP32 EMERGENCY ARCHITECTURE",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = CyberTextMuted,
                        letterSpacing = 1.sp
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    PipelineStage("Source Phones (A & B)", "GPS sensor, weather telemetry & emergency alert authoring", CyberCyan)
                    PipelineArrow("Bluetooth Low Energy (NUS RX / TX)")
                    PipelineStage("ESP32-A & ESP32-B (Source Nodes)", "Parallel BLE inputs: Node_A_Input / ESP32_NODE_B", CyberBlue)
                    PipelineArrow("ESP-NOW RF Link")
                    PipelineStage("ESP32-C (LoRa Gateway / Relay)", "Bridging ESP-NOW packets to Ra-02 SPI transceiver", CyberAmber)
                    PipelineArrow("Ra-02 Long Range (LoRa 433/868/915 MHz)")
                    PipelineStage("ESP32-D (Output Node)", "LoRa Receiver & BLE NUS beacon (${BleConstants.OUTPUT_NODE_NAME})", CyberGreen)
                    PipelineArrow("Bluetooth Low Energy (NUS TX Notify)")
                    PipelineStage("Output Node Phone (Final Terminal)", "Receives emergency transmissions, alert notification & map rendering", CyberCyan)
                }
            }
        }
    }
}

@Composable
private fun NodeDiagnosticsCard(title: String, status: NodeConnectionStatus, isDemoMode: Boolean) {
    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = CyberCard),
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, CyberCardBorder, RoundedCornerShape(20.dp))
    ) {
        Column(modifier = Modifier.padding(18.dp)) {
            Text(
                text = title,
                style = MaterialTheme.typography.labelSmall,
                fontWeight = FontWeight.Bold,
                color = CyberCyan,
                letterSpacing = 1.sp
            )

            Spacer(modifier = Modifier.height(14.dp))

            DiagnosticRow("Connected Device:", status.connectedDeviceName, status.connectedDeviceName != "Not connected" || isDemoMode)
            DiagnosticRow("MAC / Address:", status.deviceAddress ?: if (isDemoMode) "SIMULATED" else "None", status.deviceAddress != null || isDemoMode)
            DiagnosticRow("State Machine Step:", if (isDemoMode) "READY (Simulated)" else status.step.label, status.isReady || isDemoMode)
            DiagnosticRow("BLE Link Connected:", if (status.bleLinkConnected || isDemoMode) "YES" else "NO", status.bleLinkConnected || isDemoMode)
            DiagnosticRow("GATT Ready:", if (status.gattReady || isDemoMode) "YES" else "NO", status.gattReady || isDemoMode)
            DiagnosticRow("NUS Service Found:", if (status.nusFound || isDemoMode) "YES" else "NO", status.nusFound || isDemoMode)
            DiagnosticRow("RX Ready (Write):", if (status.rxReady || isDemoMode) "YES" else "NO", status.rxReady || isDemoMode)
            DiagnosticRow("TX Ready (Notify):", if (status.txReady || isDemoMode) "YES" else "NO", status.txReady || isDemoMode)
            DiagnosticRow("Overall Ready:", if (status.isReady || isDemoMode) "READY" else "NOT READY", status.isReady || isDemoMode)
            DiagnosticRow("RSSI Signal:", if (status.rssi != null) "${status.rssi} dBm" else if (isDemoMode) "-48 dBm" else "N/A", status.rssi != null || isDemoMode)
        }
    }
}

@Composable
private fun DiagnosticRow(label: String, value: String, isSuccess: Boolean) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.bodySmall,
            color = CyberTextSecondary
        )
        Text(
            text = value,
            style = MaterialTheme.typography.bodySmall,
            fontWeight = FontWeight.Bold,
            color = if (isSuccess) CyberGreen else CyberTextMuted,
            fontFamily = FontFamily.Monospace
        )
    }
}

@Composable
private fun UuidDisplayBlock(title: String, uuid: String) {
    Column {
        Text(text = title, style = MaterialTheme.typography.labelSmall, color = CyberCyan, fontFamily = FontFamily.Monospace, fontSize = 10.sp)
        Text(text = uuid, style = MaterialTheme.typography.bodySmall, color = CyberTextPrimary, fontFamily = FontFamily.Monospace)
    }
}

@Composable
private fun PipelineStage(title: String, desc: String, color: Color) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .background(CyberSurface)
            .padding(10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(modifier = Modifier.size(10.dp).clip(CircleShape).background(color))
        Spacer(modifier = Modifier.width(10.dp))
        Column {
            Text(text = title, fontWeight = FontWeight.Bold, color = CyberTextPrimary, style = MaterialTheme.typography.bodySmall)
            Text(text = desc, color = CyberTextMuted, style = MaterialTheme.typography.labelSmall)
        }
    }
}

@Composable
private fun PipelineArrow(label: String) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(text = "↓ $label", fontSize = 10.sp, color = CyberCyan, fontFamily = FontFamily.Monospace)
    }
}
