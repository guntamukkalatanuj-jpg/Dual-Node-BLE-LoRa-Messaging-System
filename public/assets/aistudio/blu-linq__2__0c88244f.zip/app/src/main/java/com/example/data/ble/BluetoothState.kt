package com.example.data.ble

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

enum class SourceNodeId(val displayName: String, val bleName: String, val roleDescription: String = "") {
    NODE_A("SOURCE NODE A", BleConstants.NODE_A_NAME, "ESP32-A Input"),
    NODE_B("SOURCE NODE B", BleConstants.NODE_B_NAME, "ESP32-B Input"),
    OUTPUT_NODE("OUTPUT NODE", BleConstants.OUTPUT_NODE_NAME, "Final Terminal")
}

enum class SourceNodeSelection(val label: String) {
    NODE_A("NODE A"),
    NODE_B("NODE B"),
    AUTO("AUTO")
}

enum class NodeConnectionStep(val label: String) {
    DISCONNECTED("Disconnected"),
    SCANNING("Scanning..."),
    DEVICE_FOUND("Device Found"),
    CONNECTING("Connecting..."),
    CONNECTED("Connected"),
    DISCOVERING_SERVICES("Discovering Services"),
    NUS_FOUND("NUS Found"),
    RX_FOUND("RX Found"),
    TX_FOUND("TX Found"),
    NOTIFICATIONS_ENABLED("Notifications Enabled"),
    READY("Ready"),
    ERROR("Error")
}

data class NodeConnectionStatus(
    val nodeId: SourceNodeId,
    val expectedName: String,
    val connectedDeviceName: String = "Not connected",
    val deviceAddress: String? = null,
    val step: NodeConnectionStep = NodeConnectionStep.DISCONNECTED,
    val bleLinkConnected: Boolean = false,
    val gattReady: Boolean = false,
    val nusFound: Boolean = false,
    val rxReady: Boolean = false,
    val txReady: Boolean = false,
    val notificationsReady: Boolean = false,
    val isReady: Boolean = false,
    val rssi: Int? = null,
    val errorMessage: String? = null
)

data class DiscoveredBleDevice(
    val name: String,
    val address: String,
    val rssi: Int,
    val matchesNodeA: Boolean = false,
    val matchesNodeB: Boolean = false,
    val matchesOutputNode: Boolean = false,
    val hasNusService: Boolean = false
) {
    val isRecognizedSourceNode: Boolean
        get() = matchesNodeA || matchesNodeB

    val isRecognizedOutputNode: Boolean
        get() = matchesOutputNode
}

data class DebugLogEntry(
    val id: Long = System.nanoTime(),
    val timestamp: Long = System.currentTimeMillis(),
    val tag: String, // e.g. "[BLE-A]", "[BLE-B]", "[BLE-OUT]", "[SEND]"
    val message: String,
    val isError: Boolean = false,
    val isSuccess: Boolean = false
) {
    fun formattedTime(): String {
        val sdf = SimpleDateFormat("HH:mm:ss.SSS", Locale.getDefault())
        return sdf.format(Date(timestamp))
    }
}

// Global Diagnostics model for app status
data class BleDiagnostics(
    val isBluetoothOn: Boolean = false,
    val scannerState: String = "READY", // READY, BUSY
    val nodeAStatus: NodeConnectionStatus = NodeConnectionStatus(SourceNodeId.NODE_A, BleConstants.NODE_A_NAME),
    val nodeBStatus: NodeConnectionStatus = NodeConnectionStatus(SourceNodeId.NODE_B, BleConstants.NODE_B_NAME),
    val outputNodeStatus: NodeConnectionStatus = NodeConnectionStatus(SourceNodeId.OUTPUT_NODE, BleConstants.OUTPUT_NODE_NAME),
    val activeTxNode: SourceNodeId? = null,
    val lastTransmissionStatus: String = "Idle"
)
