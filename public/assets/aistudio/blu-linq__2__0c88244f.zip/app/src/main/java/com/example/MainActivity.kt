package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AltRoute
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Podcasts
import androidx.compose.material.icons.filled.Radio
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.ble.NodeConnectionStep
import com.example.data.ble.SourceNodeId
import com.example.ui.screens.DiagnosticsScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.ReceiverScreen
import com.example.ui.screens.TransmitterScreen
import com.example.ui.theme.BluLinQTheme
import com.example.ui.theme.CyberCard
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.CyberGreen
import com.example.ui.theme.CyberRed
import com.example.ui.theme.CyberSurface
import com.example.ui.theme.CyberTextMuted
import com.example.ui.theme.CyberTextPrimary
import com.example.ui.theme.CyberTextSecondary
import com.example.ui.viewmodel.BluLinQViewModel
import com.example.ui.viewmodel.OperatingMode

class MainActivity : ComponentActivity() {

    private val viewModel: BluLinQViewModel by viewModels()

    @OptIn(ExperimentalMaterial3Api::class)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            BluLinQTheme {
                val state by viewModel.uiState.collectAsStateWithLifecycle()
                val snackbarHostState = remember { SnackbarHostState() }

                // Snackbar alerts
                LaunchedEffect(state.statusSnackbarMessage) {
                    state.statusSnackbarMessage?.let { msg ->
                        snackbarHostState.showSnackbar(msg)
                        viewModel.clearSnackbar()
                    }
                }

                // Handle back press
                BackHandler(enabled = state.operatingMode != OperatingMode.HOME_SELECT) {
                    viewModel.setOperatingMode(OperatingMode.HOME_SELECT)
                }

                Scaffold(
                    modifier = Modifier
                        .fillMaxSize()
                        .testTag("main_scaffold"),
                    topBar = {
                        TopAppBar(
                            title = {
                                Column {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(
                                            text = "BLU-LINQ",
                                            fontWeight = FontWeight.Black,
                                            fontSize = 19.sp,
                                            color = CyberCyan,
                                            letterSpacing = 1.sp
                                        )
                                        Spacer(modifier = Modifier.width(8.dp))
                                        val indicatorColor = when {
                                            state.isDemoMode -> CyberCyan
                                            state.isAnyNodeReady -> CyberGreen
                                            state.nodeAStatus.step != NodeConnectionStep.DISCONNECTED || state.nodeBStatus.step != NodeConnectionStep.DISCONNECTED -> Color(0xFFF59E0B)
                                            else -> CyberRed
                                        }
                                        Box(
                                            modifier = Modifier
                                                .size(8.dp)
                                                .clip(CircleShape)
                                                .background(indicatorColor)
                                        )
                                    }
                                    Text(
                                        text = when (state.operatingMode) {
                                            OperatingMode.HOME_SELECT -> "4-ESP32 Emergency Communication"
                                            OperatingMode.SOURCE_A -> "Source Phone A (Node_A_Input 0x01)"
                                            OperatingMode.SOURCE_B -> "Source Phone B (ESP32_NODE_B 0x02)"
                                            OperatingMode.OUTPUT_NODE, OperatingMode.RECEIVER -> "Output Node Terminal (ESP32-D)"
                                            OperatingMode.TRANSMITTER -> "Source Nodes (ESP32-A & B)"
                                            OperatingMode.DIAGNOSTICS -> "Hardware Telemetry Diagnostics"
                                        },
                                        style = MaterialTheme.typography.labelSmall,
                                        color = CyberTextSecondary
                                    )
                                }
                            },
                            navigationIcon = {
                                if (state.operatingMode != OperatingMode.HOME_SELECT) {
                                    IconButton(
                                        onClick = { viewModel.setOperatingMode(OperatingMode.HOME_SELECT) },
                                        modifier = Modifier.testTag("nav_back_button")
                                    ) {
                                        Icon(
                                            Icons.AutoMirrored.Filled.ArrowBack,
                                            contentDescription = "Back to home",
                                            tint = CyberTextPrimary
                                        )
                                    }
                                }
                            },
                            actions = {
                                IconButton(
                                    onClick = {
                                        if (state.operatingMode == OperatingMode.DIAGNOSTICS) {
                                            viewModel.setOperatingMode(OperatingMode.HOME_SELECT)
                                        } else {
                                            viewModel.setOperatingMode(OperatingMode.DIAGNOSTICS)
                                        }
                                    },
                                    modifier = Modifier.testTag("top_bar_diagnostics_button")
                                ) {
                                    Icon(
                                        Icons.Default.AltRoute,
                                        contentDescription = "Diagnostics",
                                        tint = if (state.operatingMode == OperatingMode.DIAGNOSTICS) CyberCyan else CyberTextSecondary
                                    )
                                }
                            },
                            colors = TopAppBarDefaults.topAppBarColors(
                                containerColor = CyberCard
                            )
                        )
                    },
                    bottomBar = {
                        NavigationBar(
                            containerColor = CyberCard,
                            tonalElevation = 8.dp
                        ) {
                            NavigationBarItem(
                                selected = state.operatingMode == OperatingMode.HOME_SELECT,
                                onClick = { viewModel.setOperatingMode(OperatingMode.HOME_SELECT) },
                                icon = { Icon(Icons.Default.Home, contentDescription = "Home") },
                                label = { Text("Home", fontSize = 11.sp) },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = CyberCyan,
                                    selectedTextColor = CyberCyan,
                                    indicatorColor = CyberSurface,
                                    unselectedIconColor = CyberTextMuted,
                                    unselectedTextColor = CyberTextMuted
                                ),
                                modifier = Modifier.testTag("nav_home")
                            )

                            NavigationBarItem(
                                selected = state.operatingMode == OperatingMode.SOURCE_A,
                                onClick = { viewModel.setOperatingMode(OperatingMode.SOURCE_A) },
                                icon = { Icon(Icons.Default.Radio, contentDescription = "Source A") },
                                label = { Text("Source A", fontSize = 11.sp) },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = CyberCyan,
                                    selectedTextColor = CyberCyan,
                                    indicatorColor = CyberSurface,
                                    unselectedIconColor = CyberTextMuted,
                                    unselectedTextColor = CyberTextMuted
                                ),
                                modifier = Modifier.testTag("nav_source_a")
                            )

                            NavigationBarItem(
                                selected = state.operatingMode == OperatingMode.SOURCE_B,
                                onClick = { viewModel.setOperatingMode(OperatingMode.SOURCE_B) },
                                icon = { Icon(Icons.Default.Radio, contentDescription = "Source B") },
                                label = { Text("Source B", fontSize = 11.sp) },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = CyberCyan,
                                    selectedTextColor = CyberCyan,
                                    indicatorColor = CyberSurface,
                                    unselectedIconColor = CyberTextMuted,
                                    unselectedTextColor = CyberTextMuted
                                ),
                                modifier = Modifier.testTag("nav_source_b")
                            )

                            NavigationBarItem(
                                selected = state.operatingMode == OperatingMode.OUTPUT_NODE || state.operatingMode == OperatingMode.RECEIVER,
                                onClick = { viewModel.setOperatingMode(OperatingMode.OUTPUT_NODE) },
                                icon = {
                                    if (state.hasUnacknowledgedAlert) {
                                        BadgedBox(badge = { Badge(containerColor = CyberRed) { Text("!") } }) {
                                            Icon(Icons.Default.Podcasts, contentDescription = "Output Node")
                                        }
                                    } else {
                                        Icon(Icons.Default.Podcasts, contentDescription = "Output Node")
                                    }
                                },
                                label = { Text("Output Node", fontSize = 11.sp) },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = CyberCyan,
                                    selectedTextColor = CyberCyan,
                                    indicatorColor = CyberSurface,
                                    unselectedIconColor = CyberTextMuted,
                                    unselectedTextColor = CyberTextMuted
                                ),
                                modifier = Modifier.testTag("nav_receiver")
                            )

                            NavigationBarItem(
                                selected = state.operatingMode == OperatingMode.DIAGNOSTICS,
                                onClick = { viewModel.setOperatingMode(OperatingMode.DIAGNOSTICS) },
                                icon = { Icon(Icons.Default.AltRoute, contentDescription = "Diagnostics") },
                                label = { Text("Diagnostics", fontSize = 11.sp) },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = CyberCyan,
                                    selectedTextColor = CyberCyan,
                                    indicatorColor = CyberSurface,
                                    unselectedIconColor = CyberTextMuted,
                                    unselectedTextColor = CyberTextMuted
                                ),
                                modifier = Modifier.testTag("nav_diagnostics")
                            )
                        }
                    },
                    snackbarHost = { SnackbarHost(snackbarHostState) }
                ) { innerPadding ->
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(innerPadding)
                    ) {
                        when (state.operatingMode) {
                            OperatingMode.HOME_SELECT -> {
                                HomeScreen(
                                    state = state,
                                    onSelectMode = { viewModel.setOperatingMode(it) },
                                    onToggleDemoMode = { viewModel.toggleDemoMode(it) }
                                )
                            }
                            OperatingMode.SOURCE_A, OperatingMode.SOURCE_B, OperatingMode.TRANSMITTER -> {
                                TransmitterScreen(
                                    state = state,
                                    onMessageChange = { viewModel.setMessageText(it) },
                                    onSourceSelectionChange = { viewModel.setSourceSelection(it) },
                                    onQuickActionClick = { viewModel.onQuickActionTapped(it) },
                                    onSendAlert = { viewModel.sendCurrentAlert() },
                                    onConfirmEmergencyAction = { viewModel.confirmAndSendEmergencyAction(it) },
                                    onDismissConfirmation = { viewModel.dismissConfirmationDialog() },
                                    onRefreshLocation = { viewModel.refreshLocation() },
                                    onRefreshWeather = { viewModel.refreshWeather() },
                                    onStartScan = { viewModel.startBleScan(it) },
                                    onStopScan = { viewModel.stopBleScan() },
                                    onSelectDevice = { addr, node -> viewModel.connectDevice(addr, node) },
                                    onDisconnectNode = { viewModel.disconnectNode(it) },
                                    onClearLogs = { viewModel.clearTransmissionLogs() }
                                )
                            }
                            OperatingMode.OUTPUT_NODE, OperatingMode.RECEIVER -> {
                                ReceiverScreen(
                                    state = state,
                                    onSearchChange = { viewModel.setSearchQuery(it) },
                                    onAcknowledgeAlert = { viewModel.acknowledgeAlert(it) },
                                    onStartScan = { viewModel.startBleScan(SourceNodeId.OUTPUT_NODE) },
                                    onStopScan = { viewModel.stopBleScan() },
                                    onSelectDevice = { addr, node -> viewModel.connectDevice(addr, node) },
                                    onDisconnectBle = { viewModel.disconnectNode(SourceNodeId.OUTPUT_NODE) },
                                    onClearHistory = { viewModel.clearReceivedHistory() }
                                )
                            }
                            OperatingMode.DIAGNOSTICS -> {
                                DiagnosticsScreen(
                                    diagnostics = state.diagnostics,
                                    isDemoMode = state.isDemoMode
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
