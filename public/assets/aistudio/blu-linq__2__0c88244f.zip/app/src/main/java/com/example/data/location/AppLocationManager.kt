package com.example.data.location

import android.annotation.SuppressLint
import android.content.Context
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Bundle
import android.os.Looper
import com.example.data.model.LocationData
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationCallback
import com.google.android.gms.location.LocationRequest
import com.google.android.gms.location.LocationResult
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class AppLocationManager(private val context: Context) {

    private val fusedClient: FusedLocationProviderClient =
        LocationServices.getFusedLocationProviderClient(context)
    private val systemLocationManager: LocationManager =
        context.getSystemService(Context.LOCATION_SERVICE) as LocationManager

    private val _currentLocation = MutableStateFlow<LocationData?>(null)
    val currentLocation: StateFlow<LocationData?> = _currentLocation.asStateFlow()

    private val _isAcquiringLocation = MutableStateFlow(false)
    val isAcquiringLocation: StateFlow<Boolean> = _isAcquiringLocation.asStateFlow()

    private val _locationStatus = MutableStateFlow("Waiting for location")
    val locationStatus: StateFlow<String> = _locationStatus.asStateFlow()

    private var fusedCallback: LocationCallback? = null

    @SuppressLint("MissingPermission")
    fun requestLocationUpdate() {
        _isAcquiringLocation.value = true
        _locationStatus.value = "Acquiring GPS coordinates..."

        try {
            // First check last known location for instant response
            fusedClient.lastLocation.addOnSuccessListener { loc: Location? ->
                if (loc != null) {
                    updateLocation(loc)
                }
            }

            // Request fresh high accuracy location
            val request = LocationRequest.Builder(Priority.PRIORITY_HIGH_ACCURACY, 5000L)
                .setMinUpdateIntervalMillis(2000L)
                .setMaxUpdates(3)
                .build()

            fusedCallback = object : LocationCallback() {
                override fun onLocationResult(result: LocationResult) {
                    result.lastLocation?.let { loc ->
                        updateLocation(loc)
                    }
                    _isAcquiringLocation.value = false
                }
            }

            fusedClient.requestLocationUpdates(request, fusedCallback!!, Looper.getMainLooper())
                .addOnFailureListener {
                    fallbackSystemLocation()
                }

        } catch (_: SecurityException) {
            _locationStatus.value = "Location permissions required"
            _isAcquiringLocation.value = false
        } catch (_: Exception) {
            fallbackSystemLocation()
        }
    }

    @SuppressLint("MissingPermission")
    private fun fallbackSystemLocation() {
        try {
            val providers = listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER)
            var found = false
            for (provider in providers) {
                if (systemLocationManager.isProviderEnabled(provider)) {
                    val loc = systemLocationManager.getLastKnownLocation(provider)
                    if (loc != null) {
                        updateLocation(loc)
                        found = true
                        break
                    }
                }
            }

            if (!found) {
                // Request single update from enabled provider
                val listener = object : LocationListener {
                    override fun onLocationChanged(loc: Location) {
                        updateLocation(loc)
                        systemLocationManager.removeUpdates(this)
                        _isAcquiringLocation.value = false
                    }
                    @Deprecated("Deprecated in Java")
                    override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
                }

                for (provider in providers) {
                    if (systemLocationManager.isProviderEnabled(provider)) {
                        systemLocationManager.requestLocationUpdates(
                            provider,
                            1000L,
                            1f,
                            listener,
                            Looper.getMainLooper()
                        )
                        break
                    }
                }
            } else {
                _isAcquiringLocation.value = false
            }
        } catch (e: SecurityException) {
            _locationStatus.value = "Location permission denied"
            _isAcquiringLocation.value = false
        } catch (e: Exception) {
            _locationStatus.value = "GPS unavailable: ${e.message}"
            _isAcquiringLocation.value = false
        }
    }

    private fun updateLocation(loc: Location) {
        val data = LocationData(
            latitude = loc.latitude,
            longitude = loc.longitude,
            accuracy = loc.accuracy,
            timestamp = loc.time.takeIf { it > 0 } ?: System.currentTimeMillis()
        )
        _currentLocation.value = data
        _locationStatus.value = "GPS Fix: ${data.formattedAccuracy()}"
    }

    fun stopLocationUpdates() {
        fusedCallback?.let {
            fusedClient.removeLocationUpdates(it)
            fusedCallback = null
        }
        _isAcquiringLocation.value = false
    }
}
