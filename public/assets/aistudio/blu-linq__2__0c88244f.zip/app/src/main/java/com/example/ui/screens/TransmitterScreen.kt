package com.example.ui.screens

import android.Manifest
import android.bluetooth.BluetoothAdapter
import android.content.Intent
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Air
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.BluetoothDisabled
import androidx.compose.material.icons.filled.ClearAll
import androidx.compose.material.icons.filled.Cloud
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Hub
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.MyLocation
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Terminal
import androidx.compose.material.icons.filled.Thermostat
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material.icons.filled.WaterDrop
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.ble.DiscoveredBleDevice
import com.example.data.ble.SourceNodeId
import com.example.data.ble.SourceNodeSelection
import com.example.data.model.TransmissionLogEntity
import com.example.ui.components.BleConnectionCard
import com.example.ui.components.BleDevicePickerModal
import com.example.ui.theme.CyberAmber
import com.example.ui.theme.CyberBlue
import com.example.ui.theme.CyberBlueLight
import com.example.ui.theme.CyberCard
import com.example.ui.theme.CyberCardBorder
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.CyberGreen
import com.example.ui.theme.CyberRed
import com.example.ui.theme.CyberSurface
import com.example.ui.theme.CyberTextMuted
import com.example.ui.theme.CyberTextPrimary
import com.example.ui.theme.CyberTextSecondary
import com.example.ui.viewmodel.BluLinQUiState

@Composable
fun TransmitterScreen(
    state: BluLinQUiState,
    onMessageChange: (String) -> Unit,
    onSourceSelectionChange: (SourceNodeSelection) -> Unit,
    onQuickActionClick: (String) -> Unit,
    onSendAlert: () -> Unit,
    onConfirmEmergencyAction: (String) -> Unit,
    onDismissConfirmation: () -> Unit,
    onRefreshLocation: () -> Unit,
    onRefreshWeather: () -> Unit,
    onStartScan: (SourceNodeId?) -> Unit,
    onStopScan: () -> Unit,
    onSelectDevice: (deviceAddress: String, targetNode: SourceNodeId) -> Unit,
    onDisconnectNode: (SourceNodeId) -> Unit,
    onClearLogs: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var showDevicePicker by remember { mutableStateOf(false) }
    var activeScanNode by remember { mutableStateOf<SourceNodeId?>(null) }
    var sourceDropdownExpanded by remember { mutableStateOf(false) }
    var showDebugPanel by remember { mutableStateOf(true) }

    // BLE permission launcher
    val blePermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        val granted = permissions.values.all { it }
        if (granted) {
            onStartScan(activeScanNode)
            showDevicePicker = true
        }
    }

    // Location permission launcher
    val locationPermissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        val granted = permissions.values.all { it }
        if (granted) {
            onRefreshLocation()
        }
    }

    fun requestBleAndScan(target: SourceNodeId) {
        activeScanNode = target
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            blePermissionLauncher.launch(
                arrayOf(
                    Manifest.permission.BLUETOOTH_SCAN,
                    Manifest.permission.BLUETOOTH_CONNECT
                )
            )
        } else {
            blePermissionLauncher.launch(
                arrayOf(
                    Manifest.permission.ACCESS_FINE_LOCATION,
                    Manifest.permission.BLUETOOTH,
                    Manifest.permission.BLUETOOTH_ADMIN
                )
            )
        }
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .testTag("transmitter_screen"),
        contentPadding = PaddingValues(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // App Subtitle / System Banner
        item {
            Column(modifier = Modifier.padding(bottom = 2.dp)) {
                Text(
                    text = "BLU-LINQ",
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Black,
                    color = CyberCyan,
                    letterSpacing = 1.sp
                )
                val roleSubtitle = when (state.operatingMode) {
                    com.example.ui.viewmodel.OperatingMode.SOURCE_A -> "Source Phone A (ID 0x01) • ESP32-A Input Link"
                    com.example.ui.viewmodel.OperatingMode.SOURCE_B -> "Source Phone B (ID 0x02) • ESP32-B Input Link"
                    else -> "Emergency Communication System • Dual Source BLE Link"
                }
                Text(
                    text = roleSubtitle,
                    style = MaterialTheme.typography.labelSmall,
                    color = CyberTextSecondary
                )
            }
        }

        // Bluetooth OFF Warning Banner
        if (!state.isBluetoothOn && !state.isDemoMode) {
            item {
                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = CyberRed.copy(alpha = 0.18f)),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, CyberRed, RoundedCornerShape(14.dp))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.BluetoothDisabled, contentDescription = null, tint = CyberRed)
                        Spacer(modifier = Modifier.width(10.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Bluetooth is OFF", fontWeight = FontWeight.Bold, color = CyberRed)
                            Text("Enable Bluetooth to connect to Node A and Node B.", style = MaterialTheme.typography.bodySmall, color = CyberTextPrimary)
                        }
                        Button(
                            onClick = {
                                try {
                                    val enableBtIntent = Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE)
                                    context.startActivity(enableBtIntent)
                                } catch (_: Exception) {}
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = CyberRed, contentColor = Color.White)
                        ) {
                            Text("Enable", fontSize = 12.sp)
                        }
                    }
                }
            }
        }

        // 1. Connection Section: Independent Source-Node Cards
        item {
            val sectionTitle = when (state.operatingMode) {
                com.example.ui.viewmodel.OperatingMode.SOURCE_A -> "SOURCE NODE A (ESP32-A)"
                com.example.ui.viewmodel.OperatingMode.SOURCE_B -> "SOURCE NODE B (ESP32-B)"
                else -> "SOURCE BLE NODES"
            }
            Text(
                text = sectionTitle,
                style = MaterialTheme.typography.labelMedium,
                fontWeight = FontWeight.Bold,
                color = CyberTextMuted,
                letterSpacing = 1.sp
            )
            Spacer(modifier = Modifier.height(8.dp))
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                if (state.operatingMode != com.example.ui.viewmodel.OperatingMode.SOURCE_B) {
                    // Source Node A Card
                    BleConnectionCard(
                        status = state.nodeAStatus,
                        isDemoMode = state.isDemoMode,
                        onConnectClick = { requestBleAndScan(SourceNodeId.NODE_A) },
                        onDisconnectClick = { onDisconnectNode(SourceNodeId.NODE_A) }
                    )
                }

                if (state.operatingMode != com.example.ui.viewmodel.OperatingMode.SOURCE_A) {
                    // Source Node B Card
                    BleConnectionCard(
                        status = state.nodeBStatus,
                        isDemoMode = state.isDemoMode,
                        onConnectClick = { requestBleAndScan(SourceNodeId.NODE_B) },
                        onDisconnectClick = { onDisconnectNode(SourceNodeId.NODE_B) }
                    )
                }
            }
        }

        // 2. Source Selection & Transmission Path Indicator
        item {
            Card(
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = CyberCard),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, CyberCardBorder, RoundedCornerShape(18.dp))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "Source Node Selection:",
                                style = MaterialTheme.typography.labelSmall,
                                color = CyberTextMuted
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            if (state.operatingMode == com.example.ui.viewmodel.OperatingMode.SOURCE_A) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(CyberSurface)
                                        .padding(horizontal = 10.dp, vertical = 6.dp)
                                ) {
                                    Text(
                                        text = "NODE A (0x01)",
                                        fontWeight = FontWeight.Black,
                                        fontFamily = FontFamily.Monospace,
                                        color = CyberCyan,
                                        fontSize = 14.sp
                                    )
                                }
                            } else if (state.operatingMode == com.example.ui.viewmodel.OperatingMode.SOURCE_B) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(CyberSurface)
                                        .padding(horizontal = 10.dp, vertical = 6.dp)
                                ) {
                                    Text(
                                        text = "NODE B (0x02)",
                                        fontWeight = FontWeight.Black,
                                        fontFamily = FontFamily.Monospace,
                                        color = CyberBlueLight,
                                        fontSize = 14.sp
                                    )
                                }
                            } else {
                                // Dropdown selector button for dual-transmitter mode
                                Box {
                                    OutlinedButton(
                                        onClick = { sourceDropdownExpanded = true },
                                        shape = RoundedCornerShape(10.dp),
                                        colors = ButtonDefaults.outlinedButtonColors(contentColor = CyberCyan),
                                        modifier = Modifier.testTag("source_node_dropdown_trigger")
                                    ) {
                                        Text(
                                            text = state.sourceSelection.label,
                                            fontWeight = FontWeight.Black,
                                            fontFamily = FontFamily.Monospace,
                                            fontSize = 15.sp
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Icon(Icons.Default.ArrowDropDown, contentDescription = null)
                                    }

                                    DropdownMenu(
                                        expanded = sourceDropdownExpanded,
                                        onDismissRequest = { sourceDropdownExpanded = false },
                                        modifier = Modifier.background(CyberCard)
                                    ) {
                                        DropdownMenuItem(
                                            text = {
                                                Row(verticalAlignment = Alignment.CenterVertically) {
                                                    Text("NODE A", fontWeight = FontWeight.Bold, color = CyberTextPrimary)
                                                    Spacer(modifier = Modifier.width(8.dp))
                                                    Text(
                                                        if (state.nodeAStatus.isReady) "● Ready" else "○ Disconnected",
                                                        fontSize = 11.sp,
                                                        color = if (state.nodeAStatus.isReady) CyberGreen else CyberTextMuted
                                                    )
                                                }
                                            },
                                            onClick = {
                                                onSourceSelectionChange(SourceNodeSelection.NODE_A)
                                                sourceDropdownExpanded = false
                                            }
                                        )
                                        DropdownMenuItem(
                                            text = {
                                                Row(verticalAlignment = Alignment.CenterVertically) {
                                                    Text("NODE B", fontWeight = FontWeight.Bold, color = CyberTextPrimary)
                                                    Spacer(modifier = Modifier.width(8.dp))
                                                    Text(
                                                        if (state.nodeBStatus.isReady) "● Ready" else "○ Disconnected",
                                                        fontSize = 11.sp,
                                                        color = if (state.nodeBStatus.isReady) CyberGreen else CyberTextMuted
                                                    )
                                                }
                                            },
                                            onClick = {
                                                onSourceSelectionChange(SourceNodeSelection.NODE_B)
                                                sourceDropdownExpanded = false
                                            }
                                        )
                                        DropdownMenuItem(
                                            text = {
                                                Row(verticalAlignment = Alignment.CenterVertically) {
                                                    Text("AUTO", fontWeight = FontWeight.Bold, color = CyberCyan)
                                                    Spacer(modifier = Modifier.width(8.dp))
                                                    Text("(Picks Node A, else B)", fontSize = 11.sp, color = CyberTextMuted)
                                                }
                                            },
                                            onClick = {
                                                onSourceSelectionChange(SourceNodeSelection.AUTO)
                                                sourceDropdownExpanded = false
                                            }
                                        )
                                    }
                                }
                            }
                        }

                        // Current Source Badge
                        val effectiveNode = state.effectiveActiveNode ?: SourceNodeId.NODE_A
                        Column(horizontalAlignment = Alignment.End) {
                            Text("Current Source:", style = MaterialTheme.typography.labelSmall, color = CyberTextMuted)
                            Text(
                                text = effectiveNode.name.replace("_", " "),
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Black,
                                color = if (state.isSendEnabled) CyberGreen else CyberAmber
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Transmission Architecture Path Diagram
                    Card(
                        shape = RoundedCornerShape(10.dp),
                        colors = CardDefaults.cardColors(containerColor = CyberSurface)
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Hub, contentDescription = null, tint = CyberCyan, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "TRANSMISSION PATH",
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = CyberCyan
                                )
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            val activeNodeName = if (state.effectiveActiveNode == SourceNodeId.NODE_B) "Node B" else "Node A"
                            Text(
                                text = "Phone → BLE → $activeNodeName → ESP-NOW → Gateway C → LoRa → Output Node D → BLE → Output Phone",
                                style = MaterialTheme.typography.bodySmall,
                                fontFamily = FontFamily.Monospace,
                                color = CyberTextPrimary,
                                lineHeight = 18.sp
                            )
                        }
                    }
                }
            }
        }

        // 3. Message Input & Quick Action Card
        item {
            Card(
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = CyberCard),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, CyberCardBorder, RoundedCornerShape(18.dp))
                    .testTag("transmitter_message_card")
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Text(
                        text = "MESSAGE",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        color = CyberTextMuted,
                        letterSpacing = 1.sp
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = state.messageText,
                        onValueChange = onMessageChange,
                        placeholder = { Text("Enter your emergency message...", color = CyberTextMuted) },
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = CyberCyan,
                            unfocusedBorderColor = CyberCardBorder,
                            focusedTextColor = CyberTextPrimary,
                            unfocusedTextColor = CyberTextPrimary,
                            cursorColor = CyberCyan
                        ),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(110.dp)
                            .testTag("transmitter_message_input")
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    Text(
                        text = "Quick Actions:",
                        style = MaterialTheme.typography.labelSmall,
                        color = CyberTextSecondary
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    // Quick Action Buttons
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        items(listOf("HELP", "SOS", "FIRE", "MEDIC", "OK")) { action ->
                            val isCritical = action == "HELP" || action == "SOS" || action == "FIRE" || action == "MEDIC"
                            FilledTonalButton(
                                onClick = { onQuickActionClick(action) },
                                colors = ButtonDefaults.filledTonalButtonColors(
                                    containerColor = if (isCritical) CyberRed.copy(alpha = 0.2f) else CyberSurface,
                                    contentColor = if (isCritical) CyberRed else CyberCyan
                                ),
                                shape = RoundedCornerShape(10.dp),
                                contentPadding = PaddingValues(horizontal = 14.dp, vertical = 8.dp),
                                modifier = Modifier.testTag("quick_action_$action")
                            ) {
                                Text(action, fontWeight = FontWeight.Bold, fontFamily = FontFamily.Monospace)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Send Button with strict safety gating
                    val canSend = state.isSendEnabled && state.messageText.isNotBlank() && !state.isSending

                    Button(
                        onClick = onSendAlert,
                        enabled = canSend,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = CyberRed,
                            contentColor = Color.White,
                            disabledContainerColor = CyberSurface,
                            disabledContentColor = CyberTextMuted
                        ),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(52.dp)
                            .testTag("send_alert_button")
                    ) {
                        if (state.isSending) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(20.dp),
                                color = Color.White,
                                strokeWidth = 2.dp
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            val progressStr = state.sendProgress?.let { " (${it.first}/${it.second})" } ?: ""
                            Text("TRANSMITTING TO ${state.effectiveActiveNode?.name ?: "ESP32"}$progressStr...", fontWeight = FontWeight.Bold)
                        } else {
                            Icon(Icons.Default.Send, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            val buttonLabel = when {
                                !state.isSendEnabled -> when (state.sourceSelection) {
                                    SourceNodeSelection.NODE_A -> "CONNECT NODE A TO TRANSMIT"
                                    SourceNodeSelection.NODE_B -> "CONNECT NODE B TO TRANSMIT"
                                    SourceNodeSelection.AUTO -> "NO SOURCE ESP32 CONNECTED"
                                }
                                state.messageText.isBlank() -> "ENTER MESSAGE TO SEND"
                                else -> "SEND ALERT"
                            }
                            Text(
                                text = buttonLabel,
                                fontWeight = FontWeight.Black,
                                letterSpacing = 1.sp
                            )
                        }
                    }
                }
            }
        }

        // 4. Live Debug Console / Logging Panel (Section 15)
        item {
            Card(
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = CyberCard),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, CyberCardBorder, RoundedCornerShape(18.dp))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Terminal, contentDescription = null, tint = CyberCyan, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "LIVE DEBUG CONSOLE",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = CyberTextPrimary
                            )
                        }
                        TextButton(onClick = { showDebugPanel = !showDebugPanel }) {
                            Text(if (showDebugPanel) "Hide" else "Show", color = CyberCyan, fontSize = 12.sp)
                        }
                    }

                    if (showDebugPanel) {
                        Spacer(modifier = Modifier.height(10.dp))
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(160.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .background(Color.Black.copy(alpha = 0.85f))
                                .padding(10.dp)
                        ) {
                            if (state.debugLogs.isEmpty()) {
                                Text("Awaiting events...", color = CyberTextMuted, style = MaterialTheme.typography.bodySmall, fontFamily = FontFamily.Monospace)
                            } else {
                                LazyColumn(
                                    modifier = Modifier.fillMaxSize(),
                                    reverseLayout = true
                                ) {
                                    items(state.debugLogs.reversed(), key = { it.id }) { log ->
                                        Row(modifier = Modifier.fillMaxWidth()) {
                                            Text(
                                                text = "${log.formattedTime()} ",
                                                color = CyberTextMuted,
                                                fontSize = 11.sp,
                                                fontFamily = FontFamily.Monospace
                                            )
                                            Text(
                                                text = "${log.tag} ",
                                                color = if (log.tag.contains("BLE-A")) CyberCyan else if (log.tag.contains("BLE-B")) CyberAmber else CyberGreen,
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 11.sp,
                                                fontFamily = FontFamily.Monospace
                                            )
                                            Text(
                                                text = log.message,
                                                color = if (log.isError) CyberRed else if (log.isSuccess) CyberGreen else CyberTextPrimary,
                                                fontSize = 11.sp,
                                                fontFamily = FontFamily.Monospace
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // 5. GPS Location Telemetry Card
        item {
            Card(
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = CyberCard),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, CyberCardBorder, RoundedCornerShape(18.dp))
                    .testTag("transmitter_location_card")
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.LocationOn, contentDescription = null, tint = CyberCyan, modifier = Modifier.size(20.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "LOCATION TELEMETRY",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = CyberTextPrimary
                            )
                        }

                        OutlinedButton(
                            onClick = {
                                locationPermissionLauncher.launch(
                                    arrayOf(
                                        Manifest.permission.ACCESS_FINE_LOCATION,
                                        Manifest.permission.ACCESS_COARSE_LOCATION
                                    )
                                )
                            },
                            shape = RoundedCornerShape(10.dp),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                            modifier = Modifier.testTag("refresh_location_btn")
                        ) {
                            Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Refresh", fontSize = 12.sp)
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = "GPS Status: ${state.locationStatusMessage}",
                        style = MaterialTheme.typography.bodySmall,
                        color = if (state.locationData != null) CyberGreen else CyberTextMuted
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        TelemetryMetricItem(
                            label = "Latitude",
                            value = state.locationData?.let { String.format("%.5f", it.latitude) } ?: "--",
                            modifier = Modifier.weight(1f)
                        )
                        TelemetryMetricItem(
                            label = "Longitude",
                            value = state.locationData?.let { String.format("%.5f", it.longitude) } ?: "--",
                            modifier = Modifier.weight(1f)
                        )
                        TelemetryMetricItem(
                            label = "Accuracy",
                            value = state.locationData?.let { "±${it.accuracy.toInt()}m" } ?: "--",
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }
        }

        // 6. Weather Telemetry Card
        item {
            Card(
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = CyberCard),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, CyberCardBorder, RoundedCornerShape(18.dp))
                    .testTag("transmitter_weather_card")
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Cloud, contentDescription = null, tint = CyberCyan, modifier = Modifier.size(20.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "WEATHER TELEMETRY",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = CyberTextPrimary
                            )
                        }

                        OutlinedButton(
                            onClick = onRefreshWeather,
                            shape = RoundedCornerShape(10.dp),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                            modifier = Modifier.testTag("refresh_weather_btn")
                        ) {
                            Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Refresh", fontSize = 12.sp)
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    val weather = state.weatherData
                    val weatherStatus = when {
                        state.isAcquiringWeather -> "Fetching Open-Meteo weather..."
                        weather != null && weather.isAvailable -> "Weather Updated (${weather.condition})"
                        else -> "Waiting for coordinates or network"
                    }

                    Text(
                        text = "Status: $weatherStatus",
                        style = MaterialTheme.typography.bodySmall,
                        color = if (weather?.isAvailable == true) CyberGreen else CyberTextMuted
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        TelemetryMetricItem(
                            label = "Temp",
                            value = weather?.let { "${it.temperature ?: "--"}°C" } ?: "--",
                            modifier = Modifier.weight(1f)
                        )
                        TelemetryMetricItem(
                            label = "Feels Like",
                            value = weather?.let { "${it.feelsLike ?: "--"}°C" } ?: "--",
                            modifier = Modifier.weight(1f)
                        )
                        TelemetryMetricItem(
                            label = "Humidity",
                            value = weather?.let { "${it.humidity ?: "--"}%" } ?: "--",
                            modifier = Modifier.weight(1f)
                        )
                        TelemetryMetricItem(
                            label = "Wind",
                            value = weather?.let { "${it.windSpeed ?: "--"} km/h" } ?: "--",
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }
        }

        // 7. Transmission Log Table / History
        item {
            Card(
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = CyberCard),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, CyberCardBorder, RoundedCornerShape(18.dp))
                    .testTag("transmission_log_card")
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "TRANSMISSION LOG",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = CyberTextPrimary
                        )

                        if (state.transmissionLogs.isNotEmpty()) {
                            IconButton(onClick = onClearLogs) {
                                Icon(Icons.Default.Delete, contentDescription = "Clear logs", tint = CyberTextMuted)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    if (state.transmissionLogs.isEmpty()) {
                        Text(
                            text = "No messages transmitted yet.",
                            style = MaterialTheme.typography.bodySmall,
                            color = CyberTextMuted,
                            modifier = Modifier.padding(vertical = 12.dp)
                        )
                    } else {
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            state.transmissionLogs.take(10).forEach { log ->
                                TransmissionLogRow(log = log)
                            }
                        }
                    }
                }
            }
        }
    }

    // Modal: Device Picker Modal for selected Node A or Node B
    if (showDevicePicker) {
        BleDevicePickerModal(
            title = if (activeScanNode == SourceNodeId.NODE_A) "Select Node A (Node_A_Input)" else "Select Node B (ESP32_NODE_B)",
            targetNode = activeScanNode,
            devices = state.discoveredDevices,
            isScanning = state.isScanning,
            onDeviceSelected = { dev ->
                activeScanNode?.let { node ->
                    onSelectDevice(dev.address, node)
                }
                showDevicePicker = false
            },
            onRescanClick = {
                onStartScan(activeScanNode)
            },
            onDismiss = {
                onStopScan()
                showDevicePicker = false
            }
        )
    }

    // Safety Confirmation Modal for Critical Emergency Actions (HELP, SOS, FIRE, MEDIC)
    state.activeConfirmationAction?.let { action ->
        AlertDialog(
            onDismissRequest = onDismissConfirmation,
            icon = { Icon(Icons.Default.Warning, contentDescription = null, tint = CyberRed) },
            title = {
                Text(
                    text = "CONFIRM EMERGENCY ALERT",
                    fontWeight = FontWeight.Black,
                    color = CyberRed,
                    letterSpacing = 1.sp
                )
            },
            text = {
                Column {
                    Text(
                        text = "You are about to transmit a critical '$action' alert via ${state.sourceSelection.label}.",
                        color = CyberTextPrimary
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Current GPS location and weather parameters will be attached to the transmission payload.",
                        style = MaterialTheme.typography.bodySmall,
                        color = CyberTextSecondary
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = { onConfirmEmergencyAction(action) },
                    colors = ButtonDefaults.buttonColors(containerColor = CyberRed, contentColor = Color.White)
                ) {
                    Text("TRANSMIT $action", fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = onDismissConfirmation) {
                    Text("CANCEL", color = CyberTextSecondary)
                }
            },
            containerColor = CyberCard,
            tonalElevation = 6.dp
        )
    }
}

@Composable
private fun TelemetryMetricItem(
    label: String,
    value: String,
    modifier: Modifier = Modifier
) {
    Card(
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(containerColor = CyberSurface),
        modifier = modifier
    ) {
        Column(modifier = Modifier.padding(8.dp)) {
            Text(label, style = MaterialTheme.typography.labelSmall, color = CyberTextSecondary, fontSize = 10.sp)
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                value,
                style = MaterialTheme.typography.bodyMedium,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                color = CyberTextPrimary
            )
        }
    }
}

@Composable
private fun TransmissionLogRow(log: TransmissionLogEntity) {
    val isSent = log.status.startsWith("Sent", ignoreCase = true)
    Card(
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(containerColor = CyberSurface.copy(alpha = 0.7f)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(10.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = log.message,
                        fontWeight = FontWeight.Bold,
                        color = CyberTextPrimary,
                        style = MaterialTheme.typography.bodyMedium
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "[${log.bleDevice}]",
                        fontSize = 10.sp,
                        color = CyberCyan,
                        fontFamily = FontFamily.Monospace
                    )
                }
                Text(
                    text = "${log.formattedTime()} • ${log.status}",
                    style = MaterialTheme.typography.labelSmall,
                    color = if (isSent) CyberGreen else CyberRed
                )
            }

            if (log.latitude != null && log.longitude != null) {
                Text(
                    text = "${String.format("%.4f", log.latitude)}, ${String.format("%.4f", log.longitude)}",
                    style = MaterialTheme.typography.labelSmall,
                    fontFamily = FontFamily.Monospace,
                    color = CyberTextMuted
                )
            }
        }
    }
}
