package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bluetooth
import androidx.compose.material.icons.filled.BluetoothConnected
import androidx.compose.material.icons.filled.BluetoothDisabled
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.ble.NodeConnectionStatus
import com.example.data.ble.NodeConnectionStep
import com.example.data.ble.SourceNodeId
import com.example.ui.theme.CyberAmber
import com.example.ui.theme.CyberCard
import com.example.ui.theme.CyberCardBorder
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.CyberGreen
import com.example.ui.theme.CyberRed
import com.example.ui.theme.CyberSurface
import com.example.ui.theme.CyberTextMuted
import com.example.ui.theme.CyberTextPrimary
import com.example.ui.theme.CyberTextSecondary

@Composable
fun BleConnectionCard(
    status: NodeConnectionStatus,
    isDemoMode: Boolean,
    onConnectClick: () -> Unit,
    onDisconnectClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val isConnected = status.isReady
    val isConnecting = status.step in listOf(
        NodeConnectionStep.SCANNING,
        NodeConnectionStep.DEVICE_FOUND,
        NodeConnectionStep.CONNECTING,
        NodeConnectionStep.CONNECTED,
        NodeConnectionStep.DISCOVERING_SERVICES,
        NodeConnectionStep.NUS_FOUND,
        NodeConnectionStep.RX_FOUND,
        NodeConnectionStep.TX_FOUND,
        NodeConnectionStep.NOTIFICATIONS_ENABLED
    )

    val statusDotColor = when {
        isDemoMode -> CyberCyan
        isConnected -> CyberGreen
        isConnecting -> CyberAmber
        status.step == NodeConnectionStep.ERROR -> CyberRed
        else -> CyberRed
    }

    val statusDotLabel = when {
        isDemoMode -> "Simulated Link"
        isConnected -> "Connected"
        isConnecting -> status.step.label
        status.step == NodeConnectionStep.ERROR -> "Error"
        else -> "Disconnected"
    }

    Card(
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = CyberCard),
        modifier = modifier
            .fillMaxWidth()
            .border(1.dp, CyberCardBorder, RoundedCornerShape(18.dp))
            .testTag("source_node_card_${status.nodeId.name.lowercase()}")
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            // Header: Source Node Title & Connection Dot
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = status.nodeId.displayName,
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Black,
                        color = if (status.nodeId == SourceNodeId.OUTPUT_NODE) CyberGreen else CyberCyan,
                        letterSpacing = 1.sp
                    )
                    if (status.nodeId == SourceNodeId.OUTPUT_NODE) {
                        Text(
                            text = "Final Terminal",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = CyberTextSecondary
                        )
                    }
                    Text(
                        text = status.expectedName,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = CyberTextPrimary,
                        fontFamily = FontFamily.Monospace
                    )
                }

                // Dot + status text
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .clip(RoundedCornerShape(20.dp))
                        .background(CyberSurface)
                        .padding(horizontal = 10.dp, vertical = 5.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(9.dp)
                            .clip(CircleShape)
                            .background(statusDotColor)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = statusDotLabel,
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = statusDotColor
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Technical Status Checklist (Link, GATT, NUS, RX, TX, RSSI)
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = CyberSurface.copy(alpha = 0.6f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    TelemetryRow(
                        label = "BLE Link",
                        value = if (status.bleLinkConnected || isDemoMode) "Connected" else "Disconnected",
                        isOk = status.bleLinkConnected || isDemoMode
                    )
                    TelemetryRow(
                        label = "GATT",
                        value = if (status.gattReady || isDemoMode) "Ready" else if (isConnecting) "Negotiating" else "Pending",
                        isOk = status.gattReady || isDemoMode
                    )
                    TelemetryRow(
                        label = "NUS",
                        value = if (status.nusFound || isDemoMode) "Found" else if (isConnecting) "Discovering" else "Not Found",
                        isOk = status.nusFound || isDemoMode
                    )
                    TelemetryRow(
                        label = "RX",
                        value = if (status.rxReady || isDemoMode) "Ready" else "Pending",
                        isOk = status.rxReady || isDemoMode
                    )
                    TelemetryRow(
                        label = "TX",
                        value = if (status.txReady || isDemoMode) "Ready" else "Pending",
                        isOk = status.txReady || isDemoMode
                    )
                    TelemetryRow(
                        label = "RSSI",
                        value = if (status.rssi != null) "${status.rssi} dBm" else if (isDemoMode) "-48 dBm" else "N/A",
                        isOk = status.rssi != null || isDemoMode
                    )
                }
            }

            // Error message if present
            if (status.errorMessage != null && !isDemoMode) {
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        Icons.Default.Error,
                        contentDescription = null,
                        tint = CyberRed,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = status.errorMessage,
                        style = MaterialTheme.typography.bodySmall,
                        color = CyberRed
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Action Button: Connect or Disconnect
            if (isConnected || isDemoMode) {
                OutlinedButton(
                    onClick = onDisconnectClick,
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.outlinedButtonColors(
                        contentColor = CyberRed
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("disconnect_btn_${status.nodeId.name.lowercase()}")
                ) {
                    Text("Disconnect ${status.nodeId.labelSuffix()}", fontWeight = FontWeight.Bold)
                }
            } else if (isConnecting) {
                OutlinedButton(
                    onClick = onDisconnectClick,
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("cancel_connecting_${status.nodeId.name.lowercase()}")
                ) {
                    CircularProgressIndicator(
                        modifier = Modifier.size(16.dp),
                        color = CyberAmber,
                        strokeWidth = 2.dp
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Connecting (${status.step.label})... Cancel", color = CyberAmber)
                }
            } else {
                Button(
                    onClick = onConnectClick,
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = CyberCyan,
                        contentColor = Color.Black
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("connect_btn_${status.nodeId.name.lowercase()}")
                ) {
                    Icon(Icons.Default.Bluetooth, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Connect ${status.nodeId.labelSuffix()}", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

private fun com.example.data.ble.SourceNodeId.labelSuffix(): String {
    return when (this) {
        com.example.data.ble.SourceNodeId.NODE_A -> "Node A"
        com.example.data.ble.SourceNodeId.NODE_B -> "Node B"
        com.example.data.ble.SourceNodeId.OUTPUT_NODE -> "Output Node"
    }
}

@Composable
private fun TelemetryRow(
    label: String,
    value: String,
    isOk: Boolean
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelSmall,
            color = CyberTextSecondary
        )
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(6.dp)
                    .clip(CircleShape)
                    .background(if (isOk) CyberGreen else CyberTextMuted)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = value,
                style = MaterialTheme.typography.labelSmall,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold,
                color = if (isOk) CyberTextPrimary else CyberTextMuted
            )
        }
    }
}
