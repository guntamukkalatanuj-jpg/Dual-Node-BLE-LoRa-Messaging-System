package com.example.data.model

import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

data class EmergencyPayload(
    val type: String = "ALERT",
    val message: String,
    val source: String = "NODE A", // "NODE A" or "NODE B"
    val sourceId: Int = if (source.contains("B", ignoreCase = true)) 2 else 1,
    val msgIdString: String = "",
    val isoTimestamp: String = generateIsoTimestamp(),
    val location: LocationData? = null,
    val weather: WeatherData? = null,
    val rawText: String? = null
) {
    val isEmergency: Boolean
        get() {
            val upper = message.trim().uppercase()
            return upper == "HELP" || upper == "SOS" || upper == "FIRE" || upper == "MEDIC" ||
                    upper.contains("EMERGENCY") || upper.contains("DANGER") || upper.contains("MAYDAY")
        }

    fun toJsonString(): String {
        val root = JSONObject()
        root.put("type", type)
        root.put("message", message)
        root.put("timestamp", isoTimestamp)
        root.put("source", source)
        root.put("sourceId", sourceId)
        if (msgIdString.isNotBlank()) {
            root.put("msgId", msgIdString)
        }

        if (location != null) {
            val locObj = JSONObject()
            locObj.put("latitude", location.latitude)
            locObj.put("longitude", location.longitude)
            locObj.put("accuracy", location.accuracy.toDouble())
            root.put("location", locObj)
        }

        if (weather != null && weather.isAvailable) {
            val weatherObj = JSONObject()
            weatherObj.put("temperature", weather.temperature)
            weatherObj.put("feelsLike", weather.feelsLike)
            weatherObj.put("humidity", weather.humidity)
            weatherObj.put("windSpeed", weather.windSpeed)
            weatherObj.put("condition", weather.condition)
            root.put("weather", weatherObj)
        }

        return root.toString()
    }

    companion object {
        fun generateIsoTimestamp(timeMs: Long = System.currentTimeMillis()): String {
            val sdf = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssXXX", Locale.US)
            sdf.timeZone = TimeZone.getDefault()
            return sdf.format(Date(timeMs))
        }

        /**
         * Decodes incoming BLE notification string from Node D (Output Node).
         * Strips "[Relayed]: " or "[OUTPUT]: " prefixes if present.
         * Maps source ID 0x01 -> "NODE A", source ID 0x02 -> "NODE B".
         */
        fun parseIncoming(rawInput: String): EmergencyPayload {
            var cleaned = rawInput.trim()
            if (cleaned.startsWith("[Relayed]:")) {
                cleaned = cleaned.removePrefix("[Relayed]:").trim()
            }
            if (cleaned.startsWith("[OUTPUT]:")) {
                cleaned = cleaned.removePrefix("[OUTPUT]:").trim()
            }

            try {
                if (cleaned.startsWith("{") && cleaned.endsWith("}")) {
                    val json = JSONObject(cleaned)
                    val type = json.optString("type", "ALERT")
                    val message = json.optString("message", cleaned)

                    val rawSource = json.optString("source", "")
                    val rawSourceId = json.optInt("sourceId", 0)

                    val resolvedSource = when {
                        rawSourceId == 2 || rawSource.contains("B", ignoreCase = true) || rawSource.equals("0x02", ignoreCase = true) -> "NODE B"
                        rawSourceId == 1 || rawSource.contains("A", ignoreCase = true) || rawSource.equals("0x01", ignoreCase = true) -> "NODE A"
                        rawSource.isNotBlank() -> rawSource.uppercase()
                        else -> "NODE A"
                    }
                    val finalSourceId = if (resolvedSource == "NODE B") 2 else 1

                    val msgId = when {
                        json.has("msgId") -> json.optString("msgId")
                        json.has("messageId") -> json.optString("messageId")
                        json.has("id") -> json.optString("id")
                        else -> ""
                    }

                    val timestamp = json.optString("timestamp", generateIsoTimestamp())

                    var locationData: LocationData? = null
                    if (json.has("location")) {
                        val locObj = json.getJSONObject("location")
                        locationData = LocationData(
                            latitude = locObj.optDouble("latitude", 0.0),
                            longitude = locObj.optDouble("longitude", 0.0),
                            accuracy = locObj.optDouble("accuracy", 0.0).toFloat()
                        )
                    }

                    var weatherData: WeatherData? = null
                    if (json.has("weather")) {
                        val wObj = json.getJSONObject("weather")
                        weatherData = WeatherData(
                            temperature = wObj.optDouble("temperature", 0.0),
                            feelsLike = wObj.optDouble("feelsLike", 0.0),
                            humidity = wObj.optInt("humidity", 0),
                            windSpeed = wObj.optDouble("windSpeed", 0.0),
                            condition = wObj.optString("condition", "Unknown"),
                            isAvailable = true
                        )
                    }

                    return EmergencyPayload(
                        type = type,
                        message = message,
                        source = resolvedSource,
                        sourceId = finalSourceId,
                        msgIdString = msgId,
                        isoTimestamp = timestamp,
                        location = locationData,
                        weather = weatherData,
                        rawText = rawInput
                    )
                }
            } catch (_: Exception) {
                // Fallback to plain text
            }

            // Fallback: Plain text message (check if starts with Node A / Node B prefix)
            val isFromB = cleaned.contains("NODE B", ignoreCase = true) || cleaned.contains("SRC:0x02", ignoreCase = true)
            val fallbackSource = if (isFromB) "NODE B" else "NODE A"

            return EmergencyPayload(
                type = "ALERT",
                message = cleaned,
                source = fallbackSource,
                sourceId = if (fallbackSource == "NODE B") 2 else 1,
                msgIdString = "",
                isoTimestamp = generateIsoTimestamp(),
                rawText = rawInput
            )
        }
    }
}
