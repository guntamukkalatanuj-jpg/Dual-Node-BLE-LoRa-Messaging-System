package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Blu-LinQ Cyber / Telemetry Dark Palette
val CyberBg = Color(0xFF050811)
val CyberCard = Color(0xFF0E172E)
val CyberSurface = Color(0xFF14203D)
val CyberCardBorder = Color(0xFF1E293B)

val CyberBlue = Color(0xFF2563EB)
val CyberBlueLight = Color(0xFF60A5FA)
val CyberCyan = Color(0xFF38BDF8)
val CyberGreen = Color(0xFF10B981)
val CyberGreenBg = Color(0xFF064E3B)
val CyberRed = Color(0xFFEF4444)
val CyberRedBg = Color(0xFF450A0A)
val CyberAmber = Color(0xFFF59E0B)
val CyberAmberBg = Color(0xFF451A03)

val CyberTextPrimary = Color(0xFFF8FAFC)
val CyberTextSecondary = Color(0xFF94A3B8)
val CyberTextMuted = Color(0xFF64748B)

// Material 3 dark color mapping
val BluPrimary = CyberCyan
val BluOnPrimary = Color(0xFF003548)
val BluPrimaryContainer = Color(0xFF004D67)
val BluOnPrimaryContainer = Color(0xFFC3E8FF)

val BluSecondary = CyberBlue
val BluOnSecondary = Color(0xFFFFFFFF)
val BluSecondaryContainer = Color(0xFF1E3A8A)
val BluOnSecondaryContainer = Color(0xFFDBEAFE)

val BluTertiary = CyberGreen
val BluOnTertiary = Color(0xFF003824)
val BluTertiaryContainer = Color(0xFF005236)
val BluOnTertiaryContainer = Color(0xFF6FF8BC)

val BluBackground = CyberBg
val BluOnBackground = CyberTextPrimary
val BluSurface = CyberCard
val BluOnSurface = CyberTextPrimary
val BluSurfaceVariant = CyberSurface
val BluOnSurfaceVariant = CyberTextSecondary
val BluOutline = CyberCardBorder
