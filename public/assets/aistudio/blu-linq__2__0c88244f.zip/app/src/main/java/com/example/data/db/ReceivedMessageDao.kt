package com.example.data.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.ReceivedMessageEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface ReceivedMessageDao {
    @Query("SELECT * FROM received_messages ORDER BY timestamp DESC")
    fun getAllMessages(): Flow<List<ReceivedMessageEntity>>

    @Query("SELECT * FROM received_messages ORDER BY timestamp DESC LIMIT 1")
    fun getLatestMessage(): Flow<ReceivedMessageEntity?>

    @Query("SELECT * FROM received_messages WHERE messageText LIKE '%' || :query || '%' OR weatherCondition LIKE '%' || :query || '%' ORDER BY timestamp DESC")
    fun searchMessages(query: String): Flow<List<ReceivedMessageEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMessage(message: ReceivedMessageEntity): Long

    @Update
    suspend fun updateMessage(message: ReceivedMessageEntity)

    @Query("UPDATE received_messages SET isAcknowledged = 1 WHERE id = :id")
    suspend fun acknowledgeMessage(id: Long)

    @Query("SELECT COUNT(*) FROM received_messages WHERE sourceNode = :sourceNode AND messageId = :messageId")
    suspend fun countBySourceAndMessageId(sourceNode: String, messageId: String): Int

    @Query("DELETE FROM received_messages")
    suspend fun clearAllMessages()

    @Query("SELECT COUNT(*) FROM received_messages")
    suspend fun getCount(): Int
}
