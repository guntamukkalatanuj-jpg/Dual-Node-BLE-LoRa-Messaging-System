package com.example.ui.viewmodel

import android.app.Application
import android.content.Context
import android.media.AudioManager
import android.media.ToneGenerator
import android.os.Build
import android.os.CombinedVibration
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.ble.BleConstants
import com.example.data.ble.BleDiagnostics
import com.example.data.ble.BleManager
import com.example.data.ble.DebugLogEntry
import com.example.data.ble.DiscoveredBleDevice
import com.example.data.ble.NodeConnectionStatus
import com.example.data.ble.SourceNodeId
import com.example.data.ble.SourceNodeSelection
import com.example.data.ble.TransmissionResult
import com.example.data.db.BluLinQDatabase
import com.example.data.location.AppLocationManager
import com.example.data.model.EmergencyPayload
import com.example.data.model.LocationData
import com.example.data.model.ReceivedMessageEntity
import com.example.data.model.TransmissionLogEntity
import com.example.data.model.WeatherData
import com.example.data.repository.EmergencyMessageRepository
import com.example.data.weather.WeatherRepository
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

enum class OperatingMode {
    HOME_SELECT,
    SOURCE_A,
    SOURCE_B,
    OUTPUT_NODE,
    TRANSMITTER,
    RECEIVER,
    DIAGNOSTICS
}

data class BluLinQUiState(
    val operatingMode: OperatingMode = OperatingMode.TRANSMITTER,
    val isDemoMode: Boolean = false,
    val isBluetoothOn: Boolean = true,
    val nodeAStatus: NodeConnectionStatus = NodeConnectionStatus(SourceNodeId.NODE_A, BleConstants.NODE_A_NAME),
    val nodeBStatus: NodeConnectionStatus = NodeConnectionStatus(SourceNodeId.NODE_B, BleConstants.NODE_B_NAME),
    val outputNodeStatus: NodeConnectionStatus = NodeConnectionStatus(SourceNodeId.OUTPUT_NODE, BleConstants.OUTPUT_NODE_NAME),
    val sourceSelection: SourceNodeSelection = SourceNodeSelection.NODE_A,
    val effectiveActiveNode: SourceNodeId? = SourceNodeId.NODE_A,
    val isSendEnabled: Boolean = false,
    val debugLogs: List<DebugLogEntry> = emptyList(),
    val discoveredDevices: List<DiscoveredBleDevice> = emptyList(),
    val isScanning: Boolean = false,
    val scanTarget: SourceNodeId? = null,
    val messageText: String = "",
    val locationData: LocationData? = null,
    val isAcquiringLocation: Boolean = false,
    val locationStatusMessage: String = "Waiting for location",
    val weatherData: WeatherData? = null,
    val isAcquiringWeather: Boolean = false,
    val isSending: Boolean = false,
    val sendProgress: Pair<Int, Int>? = null, // part to total
    val activeConfirmationAction: String? = null, // e.g. "HELP", "SOS", "FIRE", "MEDIC"
    val transmissionLogs: List<TransmissionLogEntity> = emptyList(),
    val receivedMessages: List<ReceivedMessageEntity> = emptyList(),
    val latestReceivedMessage: ReceivedMessageEntity? = null,
    val hasUnacknowledgedAlert: Boolean = false,
    val searchQuery: String = "",
    val statusSnackbarMessage: String? = null
) {
    val isAnyNodeReady: Boolean
        get() = nodeAStatus.isReady || nodeBStatus.isReady

    val diagnostics: BleDiagnostics
        get() = BleDiagnostics(
            isBluetoothOn = isBluetoothOn,
            scannerState = if (isScanning) "BUSY" else "READY",
            nodeAStatus = nodeAStatus,
            nodeBStatus = nodeBStatus,
            outputNodeStatus = outputNodeStatus,
            activeTxNode = effectiveActiveNode
        )

    val selectedNodeStatus: NodeConnectionStatus
        get() = when (sourceSelection) {
            SourceNodeSelection.NODE_A -> nodeAStatus
            SourceNodeSelection.NODE_B -> nodeBStatus
            SourceNodeSelection.AUTO -> if (nodeAStatus.isReady) nodeAStatus else nodeBStatus
        }
}

class BluLinQViewModel(application: Application) : AndroidViewModel(application) {

    private val database = BluLinQDatabase.getDatabase(application)
    private val repository = EmergencyMessageRepository(
        database.transmissionLogDao(),
        database.receivedMessageDao()
    )
    val bleManager = BleManager(application, viewModelScope)
    private val locationManager = AppLocationManager(application)
    private val weatherRepository = WeatherRepository()

    private val _operatingMode = MutableStateFlow(OperatingMode.TRANSMITTER)
    val operatingMode: StateFlow<OperatingMode> = _operatingMode.asStateFlow()

    private val _isDemoMode = MutableStateFlow(false)
    val isDemoMode: StateFlow<Boolean> = _isDemoMode.asStateFlow()

    private val _sourceSelection = MutableStateFlow(SourceNodeSelection.NODE_A)
    val sourceSelection: StateFlow<SourceNodeSelection> = _sourceSelection.asStateFlow()

    private val _messageText = MutableStateFlow("")
    val messageText: StateFlow<String> = _messageText.asStateFlow()

    private val _weatherData = MutableStateFlow<WeatherData?>(null)
    val weatherData: StateFlow<WeatherData?> = _weatherData.asStateFlow()

    private val _isAcquiringWeather = MutableStateFlow(false)
    val isAcquiringWeather: StateFlow<Boolean> = _isAcquiringWeather.asStateFlow()

    private val _isSending = MutableStateFlow(false)
    val isSending: StateFlow<Boolean> = _isSending.asStateFlow()

    private val _sendProgress = MutableStateFlow<Pair<Int, Int>?>(null)
    val sendProgress: StateFlow<Pair<Int, Int>?> = _sendProgress.asStateFlow()

    private val _activeConfirmationAction = MutableStateFlow<String?>(null)
    val activeConfirmationAction: StateFlow<String?> = _activeConfirmationAction.asStateFlow()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _statusSnackbarMessage = MutableStateFlow<String?>(null)
    val statusSnackbarMessage: StateFlow<String?> = _statusSnackbarMessage.asStateFlow()

    val uiState: StateFlow<BluLinQUiState> = combine(
        combine(
            _operatingMode,
            _isDemoMode,
            _sourceSelection,
            combine(bleManager.nodeA.status, bleManager.nodeB.status, bleManager.outputNode.status) { a, b, out ->
                Triple(a, b, out)
            }
        ) { mode, demo, selection, nodeStatuses ->
            val (statusA, statusB, statusOut) = nodeStatuses
            val effective = when (mode) {
                OperatingMode.SOURCE_A -> SourceNodeId.NODE_A
                OperatingMode.SOURCE_B -> SourceNodeId.NODE_B
                OperatingMode.OUTPUT_NODE, OperatingMode.RECEIVER -> SourceNodeId.OUTPUT_NODE
                else -> when (selection) {
                    SourceNodeSelection.NODE_A -> SourceNodeId.NODE_A
                    SourceNodeSelection.NODE_B -> SourceNodeId.NODE_B
                    SourceNodeSelection.AUTO -> if (statusA.isReady) SourceNodeId.NODE_A else if (statusB.isReady) SourceNodeId.NODE_B else SourceNodeId.NODE_A
                }
            }
            val readyToSend = if (mode == OperatingMode.OUTPUT_NODE || mode == OperatingMode.RECEIVER) {
                false
            } else if (demo) {
                true
            } else when (mode) {
                OperatingMode.SOURCE_A -> statusA.isReady
                OperatingMode.SOURCE_B -> statusB.isReady
                else -> when (selection) {
                    SourceNodeSelection.NODE_A -> statusA.isReady
                    SourceNodeSelection.NODE_B -> statusB.isReady
                    SourceNodeSelection.AUTO -> statusA.isReady || statusB.isReady
                }
            }
            Triple(Triple(mode, demo, selection), Triple(statusA, statusB, statusOut), Pair(effective, readyToSend))
        },
        combine(
            bleManager.debugLogs,
            bleManager.discoveredDevices,
            bleManager.isScanning,
            bleManager.scanTarget,
            _messageText
        ) { logs, devices, scanning, scanTarget, text ->
            Triple(logs, Pair(devices, scanning), Pair(scanTarget, text))
        },
        combine(
            locationManager.currentLocation,
            locationManager.isAcquiringLocation,
            locationManager.locationStatus,
            _weatherData,
            _isAcquiringWeather
        ) { loc, isAcqLoc, locStatus, weather, isAcqWeather ->
            Triple(loc, Pair(isAcqLoc, locStatus), Pair(weather, isAcqWeather))
        },
        combine(
            _isSending,
            _sendProgress,
            _activeConfirmationAction,
            repository.allTransmissionLogs,
            repository.allReceivedMessages
        ) { sending, progress, confirm, txLogs, rxMsgs ->
            Triple(Pair(sending, progress), confirm, Pair(txLogs, rxMsgs))
        },
        combine(
            repository.latestReceivedMessage,
            _searchQuery,
            _statusSnackbarMessage
        ) { latestRx, search, snackbar ->
            Triple(latestRx, search, snackbar)
        }
    ) { (meta, devStates, nodeRes), (logs, devPair, textPair), (loc, locState, weatherPair), (sendPair, confirm, dbLists), (latestRx, search, snackbar) ->
        val (mode, demo, selection) = meta
        val (statusA, statusB, statusOut) = devStates
        val (effectiveNode, readyToSend) = nodeRes

        val (devices, scanning) = devPair
        val (scanTarget, text) = textPair

        val (isAcqLoc, locStatus) = locState
        val (weather, isAcqWeather) = weatherPair

        val (sending, progress) = sendPair
        val (txLogs, rxMsgs) = dbLists

        val unackAlert = latestRx != null && latestRx.isEmergency && !latestRx.isAcknowledged

        val filteredRx = if (search.isBlank()) rxMsgs else rxMsgs.filter {
            it.messageText.contains(search, ignoreCase = true) || (it.weatherCondition?.contains(search, ignoreCase = true) == true)
        }

        BluLinQUiState(
            operatingMode = mode,
            isDemoMode = demo,
            isBluetoothOn = bleManager.isBluetoothEnabled,
            nodeAStatus = statusA,
            nodeBStatus = statusB,
            outputNodeStatus = statusOut,
            sourceSelection = selection,
            effectiveActiveNode = effectiveNode,
            isSendEnabled = readyToSend,
            debugLogs = logs,
            discoveredDevices = devices,
            isScanning = scanning,
            scanTarget = scanTarget,
            messageText = text,
            locationData = loc,
            isAcquiringLocation = isAcqLoc,
            locationStatusMessage = locStatus,
            weatherData = weather,
            isAcquiringWeather = isAcqWeather,
            isSending = sending,
            sendProgress = progress,
            activeConfirmationAction = confirm,
            transmissionLogs = txLogs,
            receivedMessages = filteredRx,
            latestReceivedMessage = latestRx,
            hasUnacknowledgedAlert = unackAlert,
            searchQuery = search,
            statusSnackbarMessage = snackbar
        )
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = BluLinQUiState()
    )

    init {
        // Collect incoming BLE notifications from Node A and Node B
        viewModelScope.launch {
            bleManager.incomingDataFlow.collect { rawPayload ->
                handleIncomingBleData(rawPayload)
            }
        }

        // Whenever location updates, trigger weather retrieval for transmitter
        viewModelScope.launch {
            locationManager.currentLocation.collect { loc ->
                if (loc != null) {
                    refreshWeather(loc.latitude, loc.longitude)
                }
            }
        }

        // Request initial location
        locationManager.requestLocationUpdate()
    }

    private suspend fun handleIncomingBleData(rawPayload: String) {
        val payload = EmergencyPayload.parseIncoming(rawPayload)
        val rssi = bleManager.nodeB.status.value.rssi ?: bleManager.nodeA.status.value.rssi
        val recorded = repository.recordReceivedMessage(payload, rssi)

        if (recorded?.isEmergency == true) {
            triggerEmergencyFeedback()
        }
        if (recorded != null) {
            showSnackbar("New message received: ${recorded.messageText}")
        }
    }

    private fun triggerEmergencyFeedback() {
        val ctx = getApplication<Application>()
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val vibratorManager = ctx.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
                val effect = VibrationEffect.createWaveform(longArrayOf(0, 300, 150, 300, 150, 600), -1)
                vibratorManager?.vibrate(CombinedVibration.createParallel(effect))
            } else {
                @Suppress("DEPRECATION")
                val vibrator = ctx.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    vibrator?.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 300, 150, 300, 150, 600), -1))
                } else {
                    @Suppress("DEPRECATION")
                    vibrator?.vibrate(longArrayOf(0, 300, 150, 300, 150, 600), -1)
                }
            }

            val toneGen = ToneGenerator(AudioManager.STREAM_ALARM, 100)
            toneGen.startTone(ToneGenerator.TONE_CDMA_EMERGENCY_RINGBACK, 1500)
        } catch (_: Exception) {}
    }

    fun setOperatingMode(mode: OperatingMode) {
        _operatingMode.value = mode
        when (mode) {
            OperatingMode.SOURCE_A -> {
                _sourceSelection.value = SourceNodeSelection.NODE_A
                locationManager.requestLocationUpdate()
            }
            OperatingMode.SOURCE_B -> {
                _sourceSelection.value = SourceNodeSelection.NODE_B
                locationManager.requestLocationUpdate()
            }
            OperatingMode.TRANSMITTER -> {
                locationManager.requestLocationUpdate()
            }
            else -> {}
        }
    }

    fun toggleDemoMode(enabled: Boolean) {
        _isDemoMode.value = enabled
        bleManager.addDebugLog("[SYSTEM]", if (enabled) "Simulation Demo Mode ENABLED" else "Real Hardware Mode ENABLED")
        showSnackbar(if (enabled) "SIMULATION MODE ENABLED" else "REAL HARDWARE MODE ENABLED")
    }

    fun setSourceSelection(selection: SourceNodeSelection) {
        _sourceSelection.value = selection
        bleManager.addDebugLog("[SOURCE]", "Selected Source Node: ${selection.label}")
    }

    fun setMessageText(text: String) {
        _messageText.value = text
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun refreshLocation() {
        locationManager.requestLocationUpdate()
    }

    fun refreshWeather(latitude: Double? = null, longitude: Double? = null) {
        val lat = latitude ?: locationManager.currentLocation.value?.latitude
        val lng = longitude ?: locationManager.currentLocation.value?.longitude

        if (lat == null || lng == null) {
            _weatherData.value = WeatherData.unavailable("Waiting for GPS coordinates")
            return
        }

        viewModelScope.launch {
            _isAcquiringWeather.value = true
            val result = weatherRepository.fetchWeather(lat, lng)
            _weatherData.value = result
            _isAcquiringWeather.value = false
        }
    }

    fun onQuickActionTapped(action: String) {
        val isEmergency = action == "HELP" || action == "SOS" || action == "FIRE" || action == "MEDIC"
        if (isEmergency) {
            _activeConfirmationAction.value = action
        } else {
            _messageText.value = action
        }
    }

    fun dismissConfirmationDialog() {
        _activeConfirmationAction.value = null
    }

    fun confirmAndSendEmergencyAction(action: String) {
        _activeConfirmationAction.value = null
        _messageText.value = action
        sendCurrentAlert(action)
    }

    fun sendCurrentAlert(customMsg: String? = null) {
        if (_operatingMode.value == OperatingMode.OUTPUT_NODE || _operatingMode.value == OperatingMode.RECEIVER) {
            showSnackbar("Output Node is receive-only. Transmission is disabled.")
            return
        }

        val messageToSend = (customMsg ?: _messageText.value).trim()
        if (messageToSend.isEmpty()) {
            showSnackbar("Please enter a message before sending.")
            return
        }

        val selection = when (_operatingMode.value) {
            OperatingMode.SOURCE_A -> SourceNodeSelection.NODE_A
            OperatingMode.SOURCE_B -> SourceNodeSelection.NODE_B
            else -> _sourceSelection.value
        }
        val isAllowed = _isDemoMode.value || bleManager.isSendAllowed(selection)

        if (!isAllowed) {
            val err = when (selection) {
                SourceNodeSelection.NODE_A -> "Node A is not connected or ready."
                SourceNodeSelection.NODE_B -> "Node B is not connected or ready."
                SourceNodeSelection.AUTO -> "No source ESP32 is connected."
            }
            showSnackbar(err)
            bleManager.addDebugLog("[SEND]", "Send blocked: $err", isError = true)
            return
        }

        viewModelScope.launch {
            _isSending.value = true
            _sendProgress.value = null

            val loc = locationManager.currentLocation.value
            val weather = _weatherData.value

            val payload = EmergencyPayload(
                type = "ALERT",
                message = messageToSend,
                source = if (selection == SourceNodeSelection.NODE_B) "NODE_B" else "NODE_A",
                isoTimestamp = EmergencyPayload.generateIsoTimestamp(),
                location = loc,
                weather = weather
            )
            val jsonPayload = payload.toJsonString()

            if (_isDemoMode.value) {
                // Simulation Demo Mode
                val activeNode = if (selection == SourceNodeSelection.NODE_B) SourceNodeId.NODE_B else SourceNodeId.NODE_A
                val sentStatus = "Sent to ${if (activeNode == SourceNodeId.NODE_A) "Node A" else "Node B"} (DEMO)"

                delay(500)
                repository.recordTransmission(
                    message = messageToSend,
                    latitude = loc?.latitude,
                    longitude = loc?.longitude,
                    accuracy = loc?.accuracy,
                    temperature = weather?.temperature,
                    weatherCondition = weather?.condition,
                    bleDevice = activeNode.name,
                    status = sentStatus,
                    rawPayload = jsonPayload
                )

                // Emulate sequential relay
                bleManager.simulateIncomingRelay(jsonPayload)
                showSnackbar(sentStatus)
                _messageText.value = ""
            } else {
                // Real Hardware Fragmented Transmission
                val result = bleManager.transmitEmergencyMessage(
                    selection = selection,
                    jsonBase = jsonPayload,
                    onProgress = { part, total ->
                        _sendProgress.value = Pair(part, total)
                    }
                )

                when (result) {
                    is TransmissionResult.Success -> {
                        repository.recordTransmission(
                            message = messageToSend,
                            latitude = loc?.latitude,
                            longitude = loc?.longitude,
                            accuracy = loc?.accuracy,
                            temperature = weather?.temperature,
                            weatherCondition = weather?.condition,
                            bleDevice = result.sourceNode.name,
                            status = result.statusText,
                            rawPayload = result.finalJson
                        )
                        showSnackbar("${result.statusText} (${result.totalFragments} fragments)")
                        _messageText.value = ""
                    }
                    is TransmissionResult.Failure -> {
                        repository.recordTransmission(
                            message = messageToSend,
                            latitude = loc?.latitude,
                            longitude = loc?.longitude,
                            accuracy = loc?.accuracy,
                            temperature = weather?.temperature,
                            weatherCondition = weather?.condition,
                            bleDevice = result.sourceNode?.name ?: selection.name,
                            status = "FAILED",
                            rawPayload = jsonPayload
                        )
                        showSnackbar("Transmission failed: ${result.errorMessage}")
                    }
                }
            }

            _isSending.value = false
            _sendProgress.value = null
        }
    }

    fun acknowledgeAlert(messageId: Long) {
        viewModelScope.launch {
            repository.acknowledgeAlert(messageId)
            showSnackbar("Emergency alert acknowledged")
        }
    }

    fun startBleScan(targetNode: SourceNodeId? = null) {
        bleManager.startScan(targetNode)
    }

    fun stopBleScan() {
        bleManager.stopScan()
    }

    fun connectDevice(deviceAddress: String, targetNode: SourceNodeId) {
        bleManager.connectNode(targetNode, deviceAddress)
    }

    fun disconnectNode(targetNode: SourceNodeId) {
        bleManager.disconnectNode(targetNode)
    }

    fun clearReceivedHistory() {
        viewModelScope.launch {
            repository.clearReceivedHistory()
            showSnackbar("Received message history cleared")
        }
    }

    fun clearTransmissionLogs() {
        viewModelScope.launch {
            repository.clearTransmissionLogs()
            showSnackbar("Transmission log cleared")
        }
    }

    fun clearDebugLogs() {
        // clear logs
    }

    fun showSnackbar(message: String) {
        _statusSnackbarMessage.value = message
    }

    fun clearSnackbar() {
        _statusSnackbarMessage.value = null
    }

    override fun onCleared() {
        super.onCleared()
        locationManager.stopLocationUpdates()
        bleManager.disconnectAll()
    }
}
