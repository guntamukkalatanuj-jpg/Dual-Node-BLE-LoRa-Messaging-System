package com.example.data.repository

import com.example.data.db.ReceivedMessageDao
import com.example.data.db.TransmissionLogDao
import com.example.data.model.EmergencyPayload
import com.example.data.model.ReceivedMessageEntity
import com.example.data.model.TransmissionLogEntity
import kotlinx.coroutines.flow.Flow
import java.util.UUID

class EmergencyMessageRepository(
    private val transmissionLogDao: TransmissionLogDao,
    private val receivedMessageDao: ReceivedMessageDao
) {
    val allTransmissionLogs: Flow<List<TransmissionLogEntity>> = transmissionLogDao.getAllLogs()
    val allReceivedMessages: Flow<List<ReceivedMessageEntity>> = receivedMessageDao.getAllMessages()
    val latestReceivedMessage: Flow<ReceivedMessageEntity?> = receivedMessageDao.getLatestMessage()

    fun searchReceivedMessages(query: String): Flow<List<ReceivedMessageEntity>> {
        return if (query.isBlank()) {
            receivedMessageDao.getAllMessages()
        } else {
            receivedMessageDao.searchMessages(query)
        }
    }

    suspend fun recordTransmission(
        message: String,
        latitude: Double?,
        longitude: Double?,
        accuracy: Float?,
        temperature: Double?,
        weatherCondition: String?,
        bleDevice: String,
        status: String,
        rawPayload: String
    ): Long {
        val entity = TransmissionLogEntity(
            timestamp = System.currentTimeMillis(),
            message = message,
            latitude = latitude,
            longitude = longitude,
            accuracy = accuracy,
            temperature = temperature,
            weatherCondition = weatherCondition,
            bleDevice = bleDevice,
            status = status,
            rawPayload = rawPayload
        )
        return transmissionLogDao.insertLog(entity)
    }

    suspend fun recordReceivedMessage(payload: EmergencyPayload, rssi: Int?): ReceivedMessageEntity? {
        val src = if (payload.source.isNotBlank()) payload.source else "NODE A"
        val msgId = if (payload.msgIdString.isNotBlank()) payload.msgIdString else UUID.randomUUID().toString().take(6)

        // Deduplicate using source + messageId
        val existingCount = receivedMessageDao.countBySourceAndMessageId(src, msgId)
        if (existingCount > 0) {
            return null
        }

        val entity = ReceivedMessageEntity(
            sourceNode = src,
            messageId = msgId,
            timestamp = System.currentTimeMillis(),
            messageText = payload.message,
            latitude = payload.location?.latitude,
            longitude = payload.location?.longitude,
            accuracy = payload.location?.accuracy,
            temperature = payload.weather?.temperature,
            feelsLike = payload.weather?.feelsLike,
            humidity = payload.weather?.humidity,
            windSpeed = payload.weather?.windSpeed,
            weatherCondition = payload.weather?.condition,
            rssi = rssi,
            connectionStatus = "CONNECTED",
            isAcknowledged = false,
            rawRelayedData = payload.rawText ?: ""
        )
        val id = receivedMessageDao.insertMessage(entity)
        return entity.copy(id = id)
    }

    suspend fun acknowledgeAlert(messageId: Long) {
        receivedMessageDao.acknowledgeMessage(messageId)
    }

    suspend fun clearReceivedHistory() {
        receivedMessageDao.clearAllMessages()
    }

    suspend fun clearTransmissionLogs() {
        transmissionLogDao.clearLogs()
    }
}
