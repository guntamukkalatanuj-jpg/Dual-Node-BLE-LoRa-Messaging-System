package com.example.data.weather

import com.example.data.model.WeatherData
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.util.Locale
import java.util.concurrent.TimeUnit

class WeatherRepository {

    private val client = OkHttpClient.Builder()
        .connectTimeout(6, TimeUnit.SECONDS)
        .readTimeout(6, TimeUnit.SECONDS)
        .build()

    suspend fun fetchWeather(latitude: Double, longitude: Double): WeatherData = withContext(Dispatchers.IO) {
        val url = String.format(
            Locale.US,
            "https://api.open-meteo.com/v1/forecast?latitude=%.6f&longitude=%.6f&current=temperature_2m,relative_humidity_2m,apparent_temperature,weather_code,wind_speed_10m",
            latitude,
            longitude
        )

        try {
            val request = Request.Builder()
                .url(url)
                .header("User-Agent", "Blu-LinQ-Emergency-App/1.0")
                .get()
                .build()

            val response = client.newCall(request).execute()
            if (!response.isSuccessful) {
                return@withContext WeatherData.unavailable("HTTP ${response.code}")
            }

            val body = response.body?.string() ?: return@withContext WeatherData.unavailable("Empty body")
            val json = JSONObject(body)

            if (!json.has("current")) {
                return@withContext WeatherData.unavailable("Invalid weather response")
            }

            val current = json.getJSONObject("current")
            val temp = current.optDouble("temperature_2m", 0.0)
            val feelsLike = current.optDouble("apparent_temperature", temp)
            val humidity = current.optInt("relative_humidity_2m", 0)
            val windSpeed = current.optDouble("wind_speed_10m", 0.0)
            val weatherCode = current.optInt("weather_code", 0)
            val condition = WeatherData.decodeWmoCode(weatherCode)

            WeatherData(
                temperature = temp,
                feelsLike = feelsLike,
                humidity = humidity,
                windSpeed = windSpeed,
                condition = condition,
                weatherCode = weatherCode,
                isAvailable = true,
                errorMessage = null
            )
        } catch (e: Exception) {
            WeatherData.unavailable(e.localizedMessage ?: "Weather request failed")
        }
    }
}
