package com.example.data.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.data.model.TransmissionLogEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface TransmissionLogDao {
    @Query("SELECT * FROM transmission_logs ORDER BY timestamp DESC")
    fun getAllLogs(): Flow<List<TransmissionLogEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLog(log: TransmissionLogEntity): Long

    @Query("DELETE FROM transmission_logs")
    suspend fun clearLogs()

    @Query("SELECT COUNT(*) FROM transmission_logs")
    suspend fun getCount(): Int
}
