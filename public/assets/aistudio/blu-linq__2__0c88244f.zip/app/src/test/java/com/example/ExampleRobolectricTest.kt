package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.ble.BleConstants
import com.example.data.ble.BlePacketFramer
import com.example.data.model.EmergencyPayload
import com.example.data.model.LocationData
import com.example.data.model.WeatherData
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import java.nio.ByteBuffer
import java.nio.ByteOrder

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun `read string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("Blu-LinQ", appName)
    }

    @Test
    fun `test emergency flag evaluation`() {
        val sosPayload = EmergencyPayload(message = "SOS")
        assertTrue(sosPayload.isEmergency)

        val helpPayload = EmergencyPayload(message = "help")
        assertTrue(helpPayload.isEmergency)

        val firePayload = EmergencyPayload(message = "FIRE")
        assertTrue(firePayload.isEmergency)

        val medicPayload = EmergencyPayload(message = "MEDIC")
        assertTrue(medicPayload.isEmergency)

        val okPayload = EmergencyPayload(message = "OK")
        assertFalse(okPayload.isEmergency)
    }

    @Test
    fun `test payload JSON serialization includes source field`() {
        val loc = LocationData(latitude = 37.7749, longitude = -122.4194, accuracy = 4.5f)
        val weather = WeatherData(
            temperature = 22.5,
            feelsLike = 21.0,
            humidity = 55,
            windSpeed = 12.3,
            condition = "Clear",
            isAvailable = true
        )
        val payload = EmergencyPayload(
            type = "ALERT",
            message = "EVACUATION IN PROGRESS",
            source = "NODE_A",
            location = loc,
            weather = weather
        )

        val jsonStr = payload.toJsonString()
        assertTrue(jsonStr.contains("\"source\":\"NODE_A\""))
        assertTrue(jsonStr.contains("EVACUATION IN PROGRESS"))
        assertTrue(jsonStr.contains("37.7749"))

        // Simulate Node B prepending "[Relayed]: " + msg + "\n"
        val relayed = "${BleConstants.RELAYED_PREFIX}$jsonStr\n"
        val parsed = EmergencyPayload.parseIncoming(relayed)

        assertEquals("EVACUATION IN PROGRESS", parsed.message)
        assertEquals("NODE_A", parsed.source)
        assertNotNull(parsed.location)
        assertEquals(37.7749, parsed.location!!.latitude, 0.0001)
        assertNotNull(parsed.weather)
        assertEquals(22.5, parsed.weather!!.temperature ?: 0.0, 0.1)
    }

    @Test
    fun `test binary BLE 20-byte fragmentation protocol`() {
        val testJson = "{\"type\":\"ALERT\",\"message\":\"HELP\",\"source\":\"NODE_A\"}"
        val messageId = 1024
        val frames = BlePacketFramer.createFrames(messageId, testJson)

        assertTrue("Frames must not be empty", frames.isNotEmpty())

        for (frame in frames) {
            val bytes = frame.toByteArray()
            // Verify frame length: <= 20 bytes (9-byte header + <= 11 bytes payload)
            assertTrue("Frame length ${bytes.size} must be <= 20 bytes", bytes.size <= 20)
            assertTrue("Payload length ${frame.payload.size} must be <= 11 bytes", frame.payload.size <= 11)

            // Verify header bytes
            val buf = ByteBuffer.wrap(bytes).order(ByteOrder.BIG_ENDIAN)
            val magic0 = buf.get()
            val magic1 = buf.get()
            val parsedMsgId = buf.short.toInt() and 0xFFFF
            val partIndex = buf.short.toInt() and 0xFFFF
            val totalParts = buf.short.toInt() and 0xFFFF
            val len = buf.get().toInt() and 0xFF

            assertEquals(0xB1.toByte(), magic0)
            assertEquals(0x01.toByte(), magic1)
            assertEquals(1024, parsedMsgId)
            assertEquals(frames.size, totalParts)
            assertEquals(frame.payload.size, len)
        }
    }

    @Test
    fun `test output node constant and node role`() {
        assertEquals("ESP32_FINAL_RECEIVER", BleConstants.OUTPUT_NODE_NAME)
        assertEquals("OUTPUT NODE", com.example.data.ble.SourceNodeId.OUTPUT_NODE.displayName)
        assertEquals("ESP32_FINAL_RECEIVER", com.example.data.ble.SourceNodeId.OUTPUT_NODE.bleName)
    }

    @Test
    fun `test ACK detection`() {
        assertTrue(BlePacketFramer.checkIsAck("ACK|1024|1|10", 1024, 1))
        assertTrue(BlePacketFramer.checkIsAck("ACK:1024:1", 1024, 1))
        assertFalse(BlePacketFramer.checkIsAck("ACK|1024|2|10", 1024, 1))
        assertFalse(BlePacketFramer.checkIsAck("Random text", 1024, 1))
    }
}
